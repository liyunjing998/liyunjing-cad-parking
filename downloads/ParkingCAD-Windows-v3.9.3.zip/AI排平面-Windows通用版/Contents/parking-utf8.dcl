﻿ai_home : dialog {
  label = "AI排平面";
  : button { key = "parking"; label = "绘制停车场"; width = 28; is_default = true; }
  : button { key = "last"; label = "继续上次停车方案"; }
  : button { key = "site"; label = "绘制总平面图"; }
  : button { key = "cancel"; label = "关闭"; is_cancel = true; }
}
ai_units : dialog {
  label = "停车场排布";
  : popup_list { key = "unit"; label = "原图单位"; }
  : text { key = "size"; width = 46; }
  : popup_list { key = "width"; label = "支路宽度"; }
  : popup_list { key = "end"; label = "端部排布"; }
  : row {
    : button { key = "accept"; label = "确认尺寸，点出入口"; is_default = true; }
    : button { key = "cancel"; label = "取消"; is_cancel = true; }
  }
}
ai_result : dialog {
  label = "停车场方案比选";
  : image { key = "drawing"; width = 48; height = 12; fixed_width = true; fixed_height = true; color = 0; }
  : list_box { key = "schemes"; width = 46; height = 4; }
  : toggle { key = "band"; label = "显示5米检测带"; }
  : text { key = "grass"; width = 54; }
  : text { key = "clearance"; width = 54; }
  : text { key = "reason"; width = 48; }
  : row {
    : button { key = "accept"; label = "应用到原图"; is_default = true; }
    : button { key = "another"; label = "重新选地"; }
    : button { key = "cancel"; label = "关闭"; is_cancel = true; }
  }
}
