@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 -B map_service.py --port 18770 --reuse
goto done
:python
python -B map_service.py --port 18770 --reuse
:done
if errorlevel 1 pause
