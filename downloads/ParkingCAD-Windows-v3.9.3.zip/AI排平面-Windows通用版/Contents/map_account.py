"""One local map account per OS login. Only the public JS key is returned to a browser."""
import ctypes as ct
import json
import sys
import threading

SERVICE = "ParkingSitePlanner.AMap.Web"
ACCOUNT = "local-map"


class MacStore:
    def __init__(self):
        self.lib = ct.CDLL("/System/Library/Frameworks/Security.framework/Security")
        self.cf = ct.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
        ptr, u32 = ct.c_void_p, ct.c_uint32
        self.lib.SecKeychainFindGenericPassword.argtypes = [
            ptr, u32, ct.c_char_p, u32, ct.c_char_p, ct.POINTER(u32), ct.POINTER(ptr), ct.POINTER(ptr)]
        self.lib.SecKeychainAddGenericPassword.argtypes = [ptr, u32, ct.c_char_p, u32, ct.c_char_p, u32, ptr, ct.POINTER(ptr)]
        self.lib.SecKeychainItemModifyAttributesAndData.argtypes = [ptr, ptr, u32, ptr]
        self.lib.SecKeychainItemFreeContent.argtypes = [ptr, ptr]
        self.cf.CFRelease.argtypes = [ptr]
        # A locked keychain must not block a page request on an invisible prompt.
        self.lib.SecKeychainSetUserInteractionAllowed(False)
        self.ident = (None, len(SERVICE), SERVICE.encode(), len(ACCOUNT), ACCOUNT.encode())

    def access(self, record=None):
        size, data, item = ct.c_uint32(), ct.c_void_p(), ct.c_void_p()
        status = self.lib.SecKeychainFindGenericPassword(*self.ident, ct.byref(size), ct.byref(data), ct.byref(item))
        try:
            if status not in (0, -25300):
                raise OSError("本机钥匙串暂不可用")
            if record is None:
                return ct.string_at(data, size.value) if status == 0 else None
            if status == 0:
                status = self.lib.SecKeychainItemModifyAttributesAndData(item, None, len(record), record)
            else:
                status = self.lib.SecKeychainAddGenericPassword(*self.ident, len(record), record, None)
            if status != 0:
                raise OSError("本机钥匙串保存失败")
        finally:
            if data:
                self.lib.SecKeychainItemFreeContent(None, data)
            if item:
                self.cf.CFRelease(item)


class WindowsStore:
    def __init__(self):
        from ctypes import wintypes as w

        class Credential(ct.Structure):
            _fields_ = [
                ("Flags", w.DWORD), ("Type", w.DWORD), ("TargetName", w.LPWSTR), ("Comment", w.LPWSTR),
                ("LastWritten", w.FILETIME), ("CredentialBlobSize", w.DWORD), ("CredentialBlob", ct.c_void_p),
                ("Persist", w.DWORD), ("AttributeCount", w.DWORD), ("Attributes", ct.c_void_p),
                ("TargetAlias", w.LPWSTR), ("UserName", w.LPWSTR)]
        self.type = Credential
        self.lib = ct.WinDLL("Advapi32.dll", use_last_error=True)
        self.lib.CredReadW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ct.POINTER(ct.POINTER(Credential))]
        self.lib.CredWriteW.argtypes = [ct.POINTER(Credential), w.DWORD]
        self.lib.CredFree.argtypes = [ct.c_void_p]

    def access(self, record=None):
        if record is None:
            ptr = ct.POINTER(self.type)()
            if not self.lib.CredReadW(SERVICE, 1, 0, ct.byref(ptr)):
                if ct.get_last_error() == 1168:
                    return None
                raise OSError("本机凭据暂不可用")
            try:
                return ct.string_at(ptr.contents.CredentialBlob, ptr.contents.CredentialBlobSize)
            finally:
                self.lib.CredFree(ptr)
        cred, buf = self.type(), ct.create_string_buffer(record)
        cred.Type, cred.Persist, cred.TargetName, cred.UserName = 1, 2, SERVICE, ACCOUNT
        cred.CredentialBlobSize, cred.CredentialBlob = len(record), ct.cast(buf, ct.c_void_p)
        if not self.lib.CredWriteW(ct.byref(cred), 0):
            raise OSError("本机凭据保存失败")


class MapAccount:
    def __init__(self, store=None):
        self.store = store
        self.lock = threading.Lock()

    def _store(self):
        if self.store is None:
            if sys.platform == "darwin":
                self.store = MacStore()
            elif sys.platform == "win32":
                self.store = WindowsStore()
            else:
                raise OSError("请使用浏览器本地保存")
        return self.store

    def _read(self):
        raw = self._store().access()
        return json.loads(raw) if raw else {"state": "empty"}

    def read(self):
        with self.lock:
            return self._read()

    def save(self, pair, only_empty=False):
        with self.lock:
            if only_empty:
                existing = self._read()
                if existing["state"] != "empty":
                    return existing
            record = {"state": "ready", "key": pair["key"], "code": pair["code"]}
            self._store().access(json.dumps(record).encode())
            return record

    def forget(self):
        with self.lock:
            # Older browser saves must not resurrect credentials after an explicit forget.
            self._store().access(b'{"state":"forgotten"}')
        return {"state": "forgotten"}
