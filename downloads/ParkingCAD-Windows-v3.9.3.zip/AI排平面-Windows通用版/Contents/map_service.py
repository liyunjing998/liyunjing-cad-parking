"""Loopback parking editor and same-origin signing for the AMap JS API."""
import argparse
import functools
import errno
import http.client
import http.server
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import parse_qsl, unquote, urlencode, urlsplit
import webbrowser

from map_account import MapAccount

ROOT = Path(__file__).resolve().parent
ASSETS = {
    "index.html", "style.css", "studio.css", "studio.js", "vendor/clipper.js", "tree-symbols.js", "geometry.js", "roads.js",
    "planner.js", "engine.js", "examples.js", "drawing.js", "routing.js",
    "exchange.js", "cad-bridge.js", "app.js", "map-geometry.js", "map-panel.js", "raster-plan.js", "cad-plan.js", "cad-dxf-template.js",
    "依据/DBJ33T1021-2023.pdf", "依据/规则核读.md",
}
SETTINGS = "/api/amap/settings"
PROXY = "/_AMapService/"
MAP_READS = re.compile(r"/(?:v[345]/(?:map/styles|vectormap|geocode/(?:geo|regeo)|log/init|ias/register)|v[35]/place/text)$")
SEARCH_READS = {"/v3/place/text", "/v5/place/text", "/v3/geocode/geo", "/v3/geocode/regeo"}
CALLBACK_NAME = re.compile(r"[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Handler(http.server.SimpleHTTPRequestHandler):
    account = MapAccount()
    upstream = urllib.request.build_opener(NoRedirect())

    def trusted(self, settings):
        host = f"127.0.0.1:{self.server.server_port}"
        origin = "http://" + host
        if self.headers.get("Host") != host or self.headers.get("Origin", origin) != origin:
            return False
        if self.headers.get("Sec-Fetch-Site", "same-origin") != "same-origin":
            return False
        if settings:
            return self.headers.get("X-Parking-Local") == "map-settings"
        return self.headers.get("Origin") == origin or self.headers.get("Referer", "").startswith(origin + "/")

    def reply(self, status, value):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def settings(self):
        if not self.trusted(settings=True):
            return self.reply(403, {"error": "仅限本机试用页"})
        try:
            if self.command == "GET":
                record = self.account.read()
            elif self.command == "DELETE":
                record = self.account.forget()
            else:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 2048 or self.headers.get_content_type() != "application/json":
                    return self.reply(400, {"error": "无效的配置"})
                data = json.loads(self.rfile.read(size))
                if not isinstance(data, dict) or not all(isinstance(data.get(k), str) and
                        re.fullmatch(r"[a-zA-Z0-9_-]{6,128}", data[k]) for k in ("key", "code")):
                    return self.reply(400, {"error": "请输入同一高德应用的 Web Key 和安全密钥"})
                record = self.account.save(data, only_empty=data.get("migrate") is True)
            # The security code never leaves the local account store in a browser response.
            public = {"state": record["state"]}
            if record["state"] == "ready":
                public["key"] = record["key"]
            self.reply(200, public)
        except (ValueError, UnicodeError):
            self.reply(400, {"error": "无效的配置"})
        except OSError:
            self.reply(503, {"error": "系统凭据暂不可用"})

    def amap_service(self, path, query):
        if not self.trusted(settings=False) or not MAP_READS.fullmatch(path):
            return self.reply(403, {"error": "本机地图只读接口"})
        try:
            pair = self.account.read()
            if pair["state"] != "ready":
                return self.reply(409, {"error": "请先保存地图配置"})
            params = [(k,v) for k,v in parse_qsl(query, keep_blank_values=True,max_num_fields=100)
                      if k.lower() not in ("key","jscode")]
            callback = dict(params).get("callback") if path in SEARCH_READS else None
            if callback is not None:
                if len(callback) > 128 or not CALLBACK_NAME.fullmatch(callback):
                    return self.reply(400, {"error": "无效的地图回调名称"})
                # Ask for data, then encode it for the SDK's script callback with the correct MIME.
                params = [(k,v) for k,v in params if k.lower() not in ("callback","output")]
                params.append(("output","json"))
            params.extend((("key",pair["key"]),("jscode",pair["code"])))
            remote = "webapi.amap.com" if path == "/v4/map/styles" else "restapi.amap.com"
            target = "https://" + remote + path + "?" + urlencode(params)
            req = urllib.request.Request(target, headers={"Referer": f"http://127.0.0.1:{self.server.server_port}/"})
            with self.upstream.open(req, timeout=10) as response:
                body = response.read(8 * 1024 * 1024 + 1)
                if len(body) > 8 * 1024 * 1024:
                    return self.reply(502, {"error": "地图响应过大"})
                content_type = response.headers.get("Content-Type", "application/json")
                if callback is not None:
                    data = json.dumps(json.loads(body), ensure_ascii=True, allow_nan=False, separators=(",",":"))
                    body = f"{callback}({data});".encode("ascii")
                    content_type = "application/javascript; charset=utf-8"
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
        except (OSError, ValueError, urllib.error.URLError):
            self.reply(502, {"error": "高德服务暂不可用"})

    def do_GET(self):
        url = urlsplit(self.path)
        if url.path == SETTINGS:
            return self.settings()
        if url.path.startswith(PROXY):
            return self.amap_service(url.path[len(PROXY)-1:], url.query)
        super().do_GET()

    def do_POST(self):
        if self.path == SETTINGS:
            return self.settings()
        self.send_error(404)

    do_DELETE = do_POST

    def send_head(self):
        target = unquote(urlsplit(self.path).path)
        if target == "/":
            self.path = "/index.html"
        elif target[1:] not in ASSETS:
            self.send_error(404)
            return None
        return super().send_head()

    def end_headers(self):
        if self.path != SETTINGS and not self.path.startswith(PROXY):
            self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, *args):
        pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=18769)
    parser.add_argument("--reuse", action="store_true", help="Open an already running copy of the same editor.")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("端口应取 1 到 65535。")
    handler = functools.partial(Handler, directory=os.fspath(ROOT))
    url = f"http://127.0.0.1:{args.port}/"
    try:
        httpd = http.server.ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    except OSError as problem:
        if problem.errno not in (errno.EADDRINUSE, 10048):
            raise
        if args.reuse:
            connection = http.client.HTTPConnection("127.0.0.1", args.port, timeout=2)
            page = (ROOT / "index.html").read_bytes()
            try:
                connection.request("GET", "/index.html")
                result = connection.getresponse()
                if result.status == 200 and result.read(len(page) + 1) == page:
                    if not args.no_browser:
                        webbrowser.open(url)
                    return
            except (OSError, http.client.HTTPException):
                pass
            finally:
                connection.close()
        parser.exit(1, f"本机端口 {args.port} 已被占用。可直接打开 index.html，或用 --port 选择其他端口。\n")
    with httpd as server:
        print("停车场地图试用页", url, flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        server.serve_forever()


if __name__ == "__main__":
    main()
