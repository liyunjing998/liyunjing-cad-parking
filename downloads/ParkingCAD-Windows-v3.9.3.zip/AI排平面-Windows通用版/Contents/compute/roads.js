function createParkingRoads(G) {
  'use strict';
  const {add,sub,dot,dist,unit,left,on,lerp,cuts,bounds,spans,offset,strip,prepare}=G;
  const key=p=>p.map(x=>Math.round(x*1000)).join(',');
  const kerbRadius=5; // Metres, measured at the road edge.
  const crossSpacing=74; // Design spacing used by the along-edge grid, in metres.
  const roles={main:'出入口主通道',return:'回车联络道',rim:'沿边通道',row:'停车通道',cross:'横向联络道',gate:'出入口连接',infill:'补排支道'};
  function frame(zone,angle,config={},gateAlignment=null) {
    const x=[Math.cos(angle),Math.sin(angle)],y=left(x),o=zone.boundary[0];
    const local=p=>[dot(sub(p,o),x),dot(sub(p,o),y)],world=p=>add(add(o,x,p[0]),y,p[1]);
    const boundary=G.positive(zone.boundary.map(local));

    const ports={entrance:zone.entrance&&local(zone.entrance),exit:zone.exit&&local(zone.exit)};
    const survey=[boundary],width=config.wallWidth||0;
    const inward=config.wallSide==='outside'?0:config.wallSide==='center'?width/2:width;
    const gateDirs={};
    for(const [name,p] of Object.entries(ports)){
      if(!p||!gateAlignment)continue;
      if(Array.isArray(gateAlignment)){
        const port=zone[name];
        const main=gateAlignment.find(r=>r.role==='main'&&(dist(r.a,port)<.005||dist(r.b,port)<.005));
        if(main)gateDirs[name]=unit(sub(local(dist(main.a,port)<.005?main.b:main.a),p));
      }else{
        const edge=nearestEdge(p,boundary),inward=left(unit(sub(edge.b,edge.a)));
        // Continue a layout axis through the opening. Use the row direction
        // when the transverse trunk would run almost along the boundary.
        gateDirs[name]=Math.abs(inward[1])>=.5?[0,Math.sign(inward[1])]:[Math.sign(inward[0]),0];
      }
    }
    let wall=[];
    if(width){
      const outer=width>inward?offset(survey,width-inward):survey;
      wall=G.minus(outer,inward?offset(survey,-inward):survey);
      for(const [name,p] of Object.entries(ports)){
        if(!p)continue;
        const edge=nearestEdge(p,boundary),t=unit(sub(edge.b,edge.a)),normal=left(t);
        if(edge.length>.006)continue;
        const dir=gateDirs[name]||normal;
        const shared=ports.entrance&&ports.exit&&dist(ports.entrance,ports.exit)<.005;
        const clearWidth=gateDirs[name]&&shared?Math.max(6,config.w):config.w;
        const incidence=dot(dir,normal);
        if(incidence<=.001)continue;
        const reach=(2*width+clearWidth/2*Math.abs(dot(dir,t)))/incidence;
        wall=G.minus(wall,[strip(add(edge.p,dir,-reach),add(edge.p,dir,reach),clearWidth)]);
      }
    }
    const insideWall=G.intersect(wall,survey);
    const site=G.minus(survey,G.union([...insideWall,...zone.obstacles.map(r=>G.positive(r.map(local)))]));
    return {world,local,boundary,site,wall,insideWall,ports,gateDirs,access:prepare(site),angle};
  }
  function angles(zone,orientation){
    if(orientation==='x')return [0];if(orientation==='y')return [Math.PI/2];
    const edges=zone.boundary.map((p,i)=>{const q=zone.boundary[(i+1)%zone.boundary.length];return {theta:Math.atan2(q[1]-p[1],q[0]-p[0]),size:dist(p,q)};}).sort((a,b)=>b.size-a.size);
    const result=[],push=a=>{
      a=((a%Math.PI)+Math.PI)%Math.PI;
      if(result.every(b=>Math.abs(Math.sin(a-b))>.10))result.push(a);
    };
    for(const e of edges.slice(0,6))push(e.theta);
    push(edges[0].theta+Math.PI/2);
    return result.slice(0,5);
  }
  function perimeter(site,w,d){return offset(site,-(w/2+d+.12));}
  function pattern(f,w,d,kind,phase,crossShift=0,rimSetback=d,rowWidth=w) {
    const ring=kind==='ladder'||kind==='ring',roads=[],step=rowWidth+2*d+.045;
    let land=kind==='ring'?perimeter(f.site,w,rimSetback):offset(f.site,-w/2-.018);
    if(kind==='ladder'&&land.length){
      const b=bounds(land.flat()),lo=b.y0+phase*step+.002,count=Math.floor((b.y1-lo)/step);
      if(count<1)return roads;
      const hi=lo+count*step;
      land=G.intersect(land,[[[b.x0-1,lo],[b.x1+1,lo],[b.x1+1,hi],[b.x0-1,hi]]]);
    }
    if(!land.length)return roads;
    const bb=bounds(land.flat());
    function addRoad(a,b,role,perimeterId){if(dist(a,b)>.12)roads.push({a,b,role,perimeterId});}
    if(kind==='linked'||kind==='loop'){
      // A loop can pull an end connection inward to clear a notch and shorten the aisle to that junction.
      let previous=[];const rows=[];
      for(let y=bb.y0+.003+phase*step;y<bb.y1-.001;y+=step){
        const row=spans(land,y).filter(([lo,hi])=>hi-lo>2*w).map(([lo,hi])=>({lo,hi,y,contacts:{lo:[],hi:[]}}));
        for(const r of row)for(const last of previous){
          const lo=Math.max(r.lo,last.lo),hi=Math.min(r.hi,last.hi);
          if(hi-lo<2*w)continue;
          for(const side of ['lo','hi']){
            let a=[last[side],last.y],b=[r[side],y];
            if(!f.access.fits(strip(a,b,w))){
              const offsets=kind==='loop'?[.01,w*.25,w*.5,w,w+d]:[.01];
              const x=offsets.map(o=>side==='lo'?lo+o:hi-o).find(x=>
                x>=lo&&x<=hi&&f.access.fits(strip([x,last.y],[x,y],w)));
              if(x===undefined)continue;
              a=[x,last.y];b=[x,y];
            }
            addRoad(a,b,'cross');
            last.contacts[side].push(a[0]);r.contacts[side].push(b[0]);
          }
        }
        rows.push(...row);previous=row;
      }
      for(const r of rows){
        const trim=kind==='loop',end=r.contacts;
        const lo=trim&&end.lo.length?Math.min(...end.lo):r.lo;
        const hi=trim&&end.hi.length?Math.max(...end.hi):r.hi;
        if(hi>lo)addRoad([lo,r.y],[hi,r.y],'row');
      }
      return roads;
    }
    if(ring)land.forEach((r,k)=>r.forEach((a,i)=>addRoad(a,r[(i+1)%r.length],'rim',G.signed(r)>0?k:undefined)));
    function scan(at,vertical,role){
      for(const [lo,hi] of spans(land,at,vertical))if(hi-lo>(role==='row'?w*1.8:w*1.2))addRoad(vertical?[at,lo]:[lo,at],vertical?[at,hi]:[hi,at],role);
    }
    const start=ring?bb.y0+step*(phase===0||kind==='ladder'?1:phase):bb.y0+.003+phase*step;
    for(let y=start;y<bb.y1-.001;y+=step)scan(y,false,'row');
    if(!ring&&!roads.some(r=>r.role==='row'))scan((bb.y0+bb.y1)/2,false,'row');
    const span=bb.x1-bb.x0;
    if(ring){
      const count=Math.max(0,Math.ceil(span/crossSpacing)-1);
      for(let i=1;i<=count;i++)scan(bb.x0+span*i/(count+1),true,'cross');
    }else if(kind==='spine'){
      // Connect row aisles with a trunk near the fixed openings. Search its sideways position too.
      const openings=Object.values(f.ports).filter(Boolean);
      const min=bb.x0+Math.min(d,span/4),max=bb.x1-Math.min(d,span/4);
      const trunks=[];
      for(const x of openings.length?openings.map(p=>p[0]):[(min+max)/2]){
        const at=Math.max(min,Math.min(max,x+crossShift));
        if(trunks.every(t=>Math.abs(t-at)>w+2*d)){scan(at,true,'cross');trunks.push(at);}
      }
    }else{
      const count=Math.max(1,Math.ceil(span/67)),lead=Math.min(span*.20,Math.max(w/2+.35,d));
      if(count===1)scan(Math.max(bb.x0+.01,Math.min(bb.x1-.01,(phase>.55?bb.x1-lead:bb.x0+lead)+crossShift)),true,'cross');
      else for(let i=0;i<count;i++)scan(Math.max(bb.x0+.01,Math.min(bb.x1-.01,bb.x0+lead+(span-2*lead)*i/(count-1)+crossShift)),true,'cross');
    }
    return roads;
  }
  function mainMouth(f,p,end,w){
    const edge=nearestEdge(p,f.boundary),t=unit(sub(edge.b,edge.a)),normal=left(t);
    const dir=unit(sub(end,p)),side=left(dir),incidence=dot(dir,normal);
    if(edge.length>.006||incidence<=.001)return null;
    const half=w/(2*incidence);
    if(Math.min(dist(p,edge.a),dist(p,edge.b))<half-.0001 ||
       dist(p,end)<=half*Math.abs(dot(dir,t))+.0001)return null;
    const opening=[add(edge.p,t,-half),add(edge.p,t,half)];
    const face=G.positive([opening[0],opening[1],add(end,side,-w/2),add(end,side,w/2)]);
    // Collinear red-line contacts are subject to the polygon engine's rounding.
    if(!f.access.fits(face)&&G.area(G.minus([face],f.site))>.00001)return null;
    return {p,opening,normal,path:[p,end],face,message:'顺主通道接入'};
  }
  function withGateMains(f,roads,w,minLength=0){
    const ports=Object.values(f.ports).filter(Boolean);
    if(ports.length!==2)return null;
    const unique=ports.filter((p,i)=>!ports.slice(0,i).some(q=>dist(p,q)<.005));
    const mainWidth=unique.length===1?Math.max(6,w):w;

    const mains=[];
    for(const p of unique){
      const dir=f.gateDirs[p===ports[0]?'entrance':'exit'];
      const far=add(p,dir,Math.max(...f.boundary.map(q=>dist(q,p)))+w),hits=[];
      for(const r of roads){
        const hit=cuts(p,far,r.a,r.b);
        if(hit){hits.push(hit.p);continue;}
        if([r.a,r.b].every(q=>Math.abs(G.cross(dir,sub(q,p)))<.0001))
          hits.push(...[r.a,r.b].filter(q=>dot(sub(q,p),dir)>0));
      }
      const best=hits.sort((a,b)=>dist(p,a)-dist(p,b)).find(q=>dist(p,q)>=minLength&&mainMouth(f,p,q,mainWidth));
      if(!best)break;
      mains.push({a:p,b:best,role:'main',width:mainWidth});
    }
    return mains.length===unique.length?[...mains,...roads]:null;
  }
  function connectGateTrunks(f,roads,w){
    const ports=Object.values(f.ports);
    if(ports.some(p=>!p))return null;
    const shared=dist(...ports)<.005,mains=[];
    for(const p of shared?[ports[0]]:ports){
      const edge=nearestEdge(p,f.boundary),normal=left(unit(sub(edge.b,edge.a)));
      const desired=f.gateDirs[p===ports[0]?'entrance':'exit'];
      const proposals=[];
      for(const r of roads){
        const length=dist(r.a,r.b),n=Math.max(1,Math.ceil(length/w));
        for(let i=0;i<=n;i++){
          const q=lerp(r.a,r.b,i/n),d=dist(p,q);
          if(d<2*w||d>10*w)continue;
          const axis=unit(sub(q,p));
          if(dot(normal,axis)<.32)continue;
          const incidence=Math.abs(G.cross(axis,unit(sub(r.b,r.a))));
          if(incidence<.35)continue;
          proposals.push({q,cost:Math.abs(d-3*w)+w*(1-dot(desired,axis))+w*(1-incidence)});
        }
      }
      const width=shared?Math.max(w,6):w;
      const hit=proposals.sort((a,b)=>a.cost-b.cost).find(c=>mainMouth(f,p,c.q,width));
      if(!hit)return null;
      mains.push({a:p,b:hit.q,role:'main',width});
    }
    return [...mains,...roads];
  }
  // Work on the built B network: inactive portions of its trial axes must not
  // reappear when a new connection is attached.
  function returnCandidates(base,w){
    const runs=base.net.runs;
    const bays=new G.Index(12),proposals=new Map();
    for(const bay of base.parking.stalls)bays.put(bounds(bay),bay);
    function stations(r){
      const length=dist(r.a,r.b),dir=unit(sub(r.b,r.a)),steps=Math.ceil(length/(2*w));
      const values=new Set([0,length]);
      for(const inset of [w*.18,w*.55,w]){
        const t=Math.min(inset,length/2);values.add(t);values.add(length-t);
      }
      for(let i=1;i<steps;i++)values.add(length*i/steps);
      return [...values].map(d=>add(r.a,dir,d));
    }
    const samples=runs.map(stations);
    const isPort=p=>Object.values(base.f.ports).some(q=>q&&dist(q,p)<w);
    function offer(i,a,j,b){
      const length=dist(a,b);
      if(length<1.4*w||length>10*w||isPort(a)||isPort(b))return;
      const id=[key(a),key(b)].sort().join('/');
      if(proposals.has(id))return;
      const axis=unit(sub(b,a));
      for(const [r,p,toward] of [[runs[i],a,axis],[runs[j],b,axis.map(x=>-x)]]){
        // Reject near-parallel merges; allow an end to be extended forward.
        for(const tip of [r.a,r.b])if(dist(tip,p)>.01&&dot(unit(sub(tip,p)),toward)>.80)return;
      }
      const face=strip(a,b,w);
      if(!base.f.access.fits(face))return;
      for(const [k,r] of runs.entries()){
        if(k===i||k===j)continue;
        const hit=cuts(a,b,r.a,r.b);
        if(hit&&dist(a,hit.p)>.002&&dist(b,hit.p)>.002)return;
      }
      const cost=[...bays.near(bounds(face))].filter(bay=>G.overlap(face,bay)).length;
      proposals.set(id,{a,b,role:'return',cost,length});
    }
    for(let i=0;i<runs.length;i++)for(let j=0;j<i;j++){
      function toRun(from,p,to){
        const r=runs[to],hit=on(r.a,r.b,p);
        offer(from,p,to,hit.p);
        // At a clipped row end, move the junction inboard to make room
        // for its full-width outside corner while keeping the other end fixed.
        if(hit.t>.00001&&hit.t<.99999)return;
        const end=hit.t<.5?r.a:r.b,other=hit.t<.5?r.b:r.a;
        const dir=unit(sub(other,end)),length=dist(end,other);
        for(const inset of [w*.18,w*.55,w])if(inset<length/2)offer(from,p,to,add(end,dir,inset));
      }
      for(const a of samples[i])toRun(i,a,j);
      for(const b of samples[j])toRun(j,b,i);
      for(const a of [runs[i].a,runs[i].b])for(const b of [runs[j].a,runs[j].b])offer(i,a,j,b);
    }
    return [...proposals.values()].sort((a,b)=>a.cost-b.cost||a.length-b.length);
  }
  function roadPaths(graph,start,oneway=false,allowed){
      const {nodes,edges}=graph,adj=nodes.map(()=>[]);
      for(const [i,e] of edges.entries()){
        if(e.role==='return'||(allowed&&!allowed.has(i)))continue;
        const d=dist(nodes[e.from],nodes[e.to]);
        adj[e.from].push({to:e.to,d,i});
        if(!oneway||e.twoWay)adj[e.to].push({to:e.from,d,i});
      }
      const distance=nodes.map(()=>Infinity),back=nodes.map(()=>null),done=new Set();
      if(start!==undefined)distance[start]=0;
      for(;;){
        let u=-1,min=Infinity;
        for(let i=0;i<nodes.length;i++)if(!done.has(i)&&distance[i]<min){u=i;min=distance[i];}
        if(u<0)break;done.add(u);
        for(const e of adj[u])if(min+e.d<distance[e.to]){
          distance[e.to]=min+e.d;back[e.to]={node:u,edge:e.i};}
      }
      function trace(u){
        const used=[];while(back[u]){used.push(back[u].edge);u=back[u].node;}return used;
      }
      return {distance,trace};
  }
  // The added link must close a driveable circuit using the existing main approach.
  function mainCircuit(net,oneway,w,frame){
    const {nodes,edges,ports}=net.graph,link=edges.filter(e=>e.role==='return');
    if(link.length!==1 || !net.graph.connected.entrance || !net.graph.connected.exit)return null;
    for(const id of [link[0].from,link[0].to]){
      const arms=[];
      for(const edge of edges){
        if(edge.from!==id&&edge.to!==id)continue;
        const other=edge.from===id?edge.to:edge.from;
        arms.push({dir:unit(sub(nodes[other],nodes[id])),width:w});
      }
      const face=jointFace(nodes[id],arms);
      if(face&&!frame.access.fits(face))return null;
    }
    const e=link[0],detour=roadPaths(net.graph,e.to,oneway),via=detour.distance[e.from];
    if(!Number.isFinite(via)||via<Math.max(3*w,dist(nodes[e.to],nodes[e.from])*1.12))return null;
    const cycle=detour.trace(e.from),entry=roadPaths(net.graph,ports.entrance,oneway);
    const circuit=[...cycle,edges.indexOf(e)],length=via+dist(nodes[e.to],nodes[e.from]);
    if(ports.entrance===ports.exit){
      const nearest=cycle.flatMap(k=>[edges[k].from,edges[k].to]).sort((a,b)=>entry.distance[a]-entry.distance[b])[0];
      return entry.distance[nearest]<=4*w ? {shared:via,length,circuit,approach:entry.trace(nearest)}:null;
    }
    const trunk=new Set(entry.trace(ports.exit));
    const shared=cycle.filter(k=>trunk.has(k)).reduce((n,k)=>n+dist(nodes[edges[k].from],nodes[edges[k].to]),0);
    if(shared<Math.max(w,Math.min(4*w,entry.distance[ports.exit]*.23)))return null;
    return {shared,length,circuit};
  }
  function nearestEdge(p,ring){
    let best; for(let i=0;i<ring.length;i++){const a=ring[i],b=ring[(i+1)%ring.length],hit=on(a,b,p),length=dist(p,hit.p);if(!best||length<best.length)best={...hit,a,b,i,length};}
    return best;
  }
  // Only a gap exceeding 180° between outgoing arms needs extra paving.
  // Continue both straight kerbs to their intersection at a bend.
  function jointFace(p,arms){
    if(arms.length<2)return null;
    const sorted=arms.slice().sort((a,b)=>Math.atan2(a.dir[1],a.dir[0])-Math.atan2(b.dir[1],b.dir[0]));
    for(let i=0;i<sorted.length;i++){
      const a=sorted[i],b=sorted[(i+1)%sorted.length],turn=G.cross(a.dir,b.dir);
      if(turn>=-1e-7)continue;
      const n1=left(a.dir),n2=left(b.dir).map(v=>-v);
      const aEdge=add(p,n1,a.width/2),bEdge=add(p,n2,b.width/2);
      const meet=add(aEdge,a.dir,G.cross(sub(bEdge,aEdge),b.dir)/turn);
      const h=Math.max(a.width,b.width)/2;
      if(dist(p,meet)<=3*h)return G.positive([p,aEdge,meet,bEdge]);
      if(dot(a.dir,b.dir)<0)return G.positive([p,aEdge,bEdge]);
      // Two nearly parallel arms form a hairpin. End the nose with a flat face
      // across the bisector instead of projecting a long spike into the parcel.
      const out=unit(add(n1,n2)),cap=(edge,dir)=>add(edge,dir,(h-dot(sub(edge,p),out))/dot(dir,out));
      return G.positive([p,aEdge,cap(aEdge,a.dir),cap(bEdge,b.dir),bEdge]);
    }
    return null;
  }
  function gate(f,roads,p,w){
    if(!p)return {message:'尚未指定'};
    const edge=nearestEdge(p,f.boundary);
    if(edge.length>.006)return {message:'标记偏离边界'};
    const t=unit(sub(edge.b,edge.a)),normal=left(t),origin=edge.p,ends=[add(origin,t,-w/2),add(origin,t,w/2)];
    if(Math.min(dist(origin,edge.a),dist(origin,edge.b))<w/2-.001)return {message:'开口靠近顶角，整幅车道放不下'};
    const lead=add(origin,normal,w/2+.045);
    const face=strip(origin,lead,w);
    if(!f.access.fits(face))return {message:'开口净宽受场地或障碍限制'};
    const options=[];
    for(const r of roads){
      const hit=cuts(origin,add(origin,normal,100000),r.a,r.b);
      if(hit&&dot(sub(hit.p,lead),normal)>=-.02)options.push({path:[origin,hit.p],cost:dist(origin,hit.p)});
      const q=on(r.a,r.b,lead).p,l=dist(lead,q);
      if(dot(sub(q,origin),normal)>w/2-.03)options.push({path:l>.03?[origin,lead,q]:[origin,q],cost:dist(origin,lead)+l+.3});
    }
    options.sort((a,b)=>a.cost-b.cost);
    for(const {path} of options){
      if(!path.slice(1).every((b,i)=>f.access.fits(strip(path[i],b,w))))continue;
      if(path.length>2){
        const face=jointFace(lead,[{dir:unit(sub(origin,lead)),width:w},{dir:unit(sub(path[2],lead)),width:w}]);
        if(face&&!f.access.fits(face))continue;
      }
      return {p:origin,opening:ends,normal,path,message:'接入'};
    }
    return {p:origin,opening:ends,normal,message:'未找到足宽的接入路径'};
  }
  function network(raw,portInfo,oneway){
    const rawSplit=raw.map(r=>[0,1]),junctions=new G.Index(28);
    for(let i=0;i<raw.length;i++){
      const a=raw[i],box=bounds([a.a,a.b]);
      for(const j of junctions.near(box)){
        const b=raw[j],hit=cuts(a.a,a.b,b.a,b.b);
        if(hit){rawSplit[i].push(hit.t);rawSplit[j].push(hit.s);continue;}
        for(const p of [a.a,a.b]){const q=on(b.a,b.b,p);if(dist(p,q.p)<.0004)rawSplit[j].push(q.t);}
        for(const p of [b.a,b.b]){const q=on(a.a,a.b,p);if(dist(p,q.p)<.0004)rawSplit[i].push(q.t);}
      }
      junctions.put(box,i);
    }
    const nodes=[],edges=[],ids=new Map(),seen=new Map(),incident=[];
    function node(p){const k=key(p);if(!ids.has(k)){ids.set(k,nodes.length);nodes.push(p);incident.push([]);}return ids.get(k);}
    for(let i=0;i<raw.length;i++){
      const r=raw[i],ts=rawSplit[i].map(t=>Math.min(1,Math.max(0,t))).sort((a,b)=>a-b);
      for(let j=1;j<ts.length;j++){
        const a=lerp(r.a,r.b,ts[j-1]),b=lerp(r.a,r.b,ts[j]);
        if(dist(a,b)<.002)continue;
        const from=node(a),to=node(b),k=Math.min(from,to)+'/'+Math.max(from,to);
        if(from===to||seen.has(k))continue;
        const id=edges.length;edges.push({from,to,owner:i,role:r.role});seen.set(k,id);incident[from].push(id);incident[to].push(id);
      }
    }
    const ports={};for(const name of ['entrance','exit']){
      const g=portInfo[name];if(g?.path)ports[name]=ids.get(key(g.path[0]));
    }
    const comp=nodes.map(()=>-1),sizes=[];
    for(let i=0;i<nodes.length;i++)if(comp[i]<0){
      const number=sizes.length,q=[i];let size=0;comp[i]=number;
      for(let k=0;k<q.length;k++)for(const id of incident[q[k]]){const e=edges[id],v=e.from===q[k]?e.to:e.from;size+=dist(nodes[v],nodes[q[k]])/2;if(comp[v]<0){comp[v]=number;q.push(v);}}
      sizes.push(size);
    }
    const chosen=comp[ports.entrance]??comp[ports.exit]??sizes.indexOf(Math.max(...sizes));
    const filtered=edges.filter(e=>comp[e.from]===chosen);
    const connected={entrance:ports.entrance!==undefined&&comp[ports.entrance]===chosen,exit:ports.exit!==undefined&&comp[ports.exit]===chosen};
    if(!oneway||!filtered.length)return {nodes,edges:filtered,ports,connected};
    // Orient cycles consistently even when two gates share an opening. The virtual return link is removed before reachability checks.
    const shared=connected.entrance&&connected.exit&&ports.entrance===ports.exit;
    const start=connected.entrance?ports.entrance:filtered[0].from,finish=connected.exit?ports.exit:start;
    const virtual=finish!==start?{from:finish,to:start,virtual:true}:null;
    const all=virtual?[virtual,...filtered]:filtered,adj=nodes.map(()=>[]),visited=new Set(),used=new Set(),oriented=[];
    all.forEach((e,i)=>{adj[e.from].push(i);adj[e.to].push(i);});
    function walk(u){visited.add(u);for(const id of adj[u]){if(used.has(id))continue;used.add(id);const e=all[id],v=e.from===u?e.to:e.from;if(!e.virtual)oriented.push({...e,from:u,to:v,twoWay:shared&&(e.role==='gate'||e.role==='main')});if(!visited.has(v))walk(v);}}
    walk(finish);
    function reach(origin,reverse){
      const links=nodes.map(()=>[]);for(const e of oriented){links[reverse?e.to:e.from].push(reverse?e.from:e.to);if(e.twoWay)links[reverse?e.from:e.to].push(reverse?e.to:e.from);}
      const set=new Set([origin]),q=[origin];for(let i=0;i<q.length;i++)for(const v of links[q[i]])if(!set.has(v)){set.add(v);q.push(v);}return set;
    }
    const from=reach(start,false),to=reach(finish,true);
    const possible=oriented.filter(e=>from.has(e.from)&&to.has(e.to));
    if(!from.has(finish)||!possible.length){connected.entrance=false;connected.exit=false;}
    return {nodes,edges:possible,ports,connected};
  }
  function primaryRoute(graph,axes,f,w){
    const {nodes,edges,ports,connected}=graph,main=new Set(),rims=new Map();
    const hasTrunk=edges.some(e=>e.role==='main'||e.role==='return');
    for(const [i,e] of edges.entries()){
      const r=axes[e.owner];
      if(r.primary||e.role==='main'||e.role==='gate')main.add(i);
      if(!hasTrunk&&r.perimeterId!==undefined){
        if(!rims.has(r.perimeterId))rims.set(r.perimeterId,{length:0,edges:[],nodes:new Set()});
        const rim=rims.get(r.perimeterId);
        rim.length+=dist(nodes[e.from],nodes[e.to]);rim.edges.push(i);rim.nodes.add(e.from);rim.nodes.add(e.to);
      }
    }
    const rim=[...rims.values()].sort((a,b)=>b.length-a.length)[0];
    if(rim){
      for(const id of rim.edges)main.add(id);
      for(const key of ['entrance','exit'])if(connected[key]){
        const path=roadPaths(graph,ports[key]);
        const nearest=[...rim.nodes].reduce((a,b)=>path.distance[a]<path.distance[b]?a:b);
        for(const id of path.trace(nearest))main.add(id);
      }
    }else if(connected.entrance&&connected.exit){
      const path=roadPaths(graph,ports.entrance);
      for(const id of path.trace(ports.exit))main.add(id);
      if(edges.some(e=>e.role==='return')){
        const loop=mainCircuit({graph},false,w,f);
        if(loop)for(const id of [...loop.circuit,...(loop.approach||[])])main.add(id);
      }
    }
    return main;
  }
  function assignTraffic(graph,axes,frame,w,serviceWidth){
    const {nodes,edges,ports}=graph,adj=nodes.map(()=>[]);
    const primary=primaryRoute(graph,axes,frame,w);
    const trunk=new Set(roadPaths(graph,ports.entrance,false,primary).trace(ports.exit));
    edges.forEach((e,i)=>{
      adj[e.from].push(i);adj[e.to].push(i);
      e.trunk=trunk.has(i);e.primary=primary.has(i);e.width=e.primary?w:serviceWidth;e.twoWay=true;e.bridge=false;
    });
    // Tree arcs lead away from the entrance and back arcs lead towards it.
    // A bridge has no return path, so it must remain wide enough for two-way travel.
    const order=nodes.map(()=>0),low=nodes.map(()=>0),seen=new Set();
    let time=0;
    function walk(u){
      low[u]=order[u]=++time;
      for(const i of adj[u]){
        if(seen.has(i))continue;
        seen.add(i);
        const e=edges[i],v=e.from===u?e.to:e.from;
        e.from=u;e.to=v;
        if(order[v])low[u]=Math.min(low[u],order[v]);
        else{
          walk(v);low[u]=Math.min(low[u],low[v]);
          e.bridge=low[v]>order[u];
        }
      }
    }
    if(edges.length)walk(graph.connected.entrance?ports.entrance:edges[0].from);
  }
  function assemble(f,roads,w,oneway,config){
    const portInfo={};const all=roads.slice();
    const shared=f.ports.entrance&&f.ports.exit&&dist(f.ports.entrance,f.ports.exit)<.005;
    const gateWidth=shared?Math.max(6,w):w;
    for(const k of ['entrance','exit']){
      if(shared&&k==='exit'){portInfo.exit=portInfo.entrance;continue;}
      const port=f.ports[k];
      const main=port&&roads.find(r=>r.role==='main'&&(dist(r.a,port)<.005||dist(r.b,port)<.005));
      if(main){
        const g=mainMouth(f,port,dist(main.a,port)<.005?main.b:main.a,gateWidth);
        portInfo[k]=g||{message:'主通道开口净宽不足'};continue;
      }
      const g=gate(f,roads,f.ports[k],gateWidth);
      portInfo[k]=g;
      if(g.path)for(let i=1;i<g.path.length;i++)all.push({a:g.path[i-1],b:g.path[i],role:'gate',width:gateWidth});
    }
    const graph=network(all,portInfo,oneway);
    if(config?.hierarchy)assignTraffic(graph,all,f,w,config.serviceWidth);
    return roadGeometry(f,all,graph,portInfo,w);
  }
  // Locate only intersections of incident kerbs. Gate mouths, dead-end caps,
  // changes in width along a straight, and surveyed parcel vertices are not turns.
  function cornerKeys(joints,graph){
    const corners=new Map();
    for(const [id,arms] of joints){
      if(arms.length<2||id===graph.ports.entrance||id===graph.ports.exit)continue;
      const sorted=arms.slice().sort((a,b)=>Math.atan2(a.dir[1],a.dir[0])-Math.atan2(b.dir[1],b.dir[0]));
      for(let i=0;i<sorted.length;i++){
        const a=sorted[i],b=sorted[(i+1)%sorted.length],turn=G.cross(a.dir,b.dir);
        if(Math.abs(turn)<1e-6)continue;
        const p=graph.nodes[id],u=add(p,left(a.dir),a.width/2),v=add(p,left(b.dir),-b.width/2);
        const inner=turn>0,width=(a.width+b.width)/2;
        const point=add(u,a.dir,G.cross(sub(v,u),b.dir)/turn);
        corners.set(key(point),{node:id,arms:[a.other,b.other],inner,width,
          equalWidth:Math.abs(a.width-b.width)<1e-6,ordinaryBend:arms.length===2,radius:inner?kerbRadius:kerbRadius+width});
      }
    }
    return corners;
  }
  function filletKerbs(surface,site,corners){
    const arcs=[],taken=new G.Index(12),innerBends=new Set();
    const limits={short:0,clearance:0,transition:0};
    const rings=surface.map(points=>({points,turns:[],used:points.map(()=>0),
      lengths:points.map((p,i)=>dist(p,points[(i+1)%points.length]))}));
    const candidates=[];
    for(const ring of rings)for(const [i,p] of ring.points.entries()){
      const corner=corners.get(key(p));
      if(corner)candidates.push({ring,i,corner});
    }
    // Reserve the inside first. Trimming the outside without its inside
    // offset could pinch the road below its specified clear width.
    candidates.sort((a,b)=>Number(b.corner.inner)-Number(a.corner.inner));
    let insideRoad,availableGround;
    for(const {ring:{points:ring,turns,used,lengths},i,corner} of candidates){
      const p=ring[i],count=ring.length,prev=(i+count-1)%count,next=(i+1)%count;
      const u=unit(sub(p,ring[prev])),v=unit(sub(ring[next],p));
      const turn=Math.atan2(G.cross(u,v),dot(u,v)),sweep=Math.abs(turn);
      if(sweep<Math.PI/180)continue;
      // A taper needs its own transition. Leave the outer envelope wide.
      if(!corner.inner && (!corner.ordinaryBend||!corner.equalWidth||!innerBends.has(corner.node))){limits.transition++;continue;}
      const r=corner.radius,trim=r*Math.tan(sweep/2);
      if(trim+used[prev]>lengths[prev]+1e-7||trim+used[i]>lengths[i]+1e-7){limits.short++;continue;}
      const begin=add(p,u,-trim),end=add(p,v,trim),triangle=[begin,p,end],box=bounds(triangle);
      const room=turn>0?(insideRoad??=prepare(surface)):(availableGround??=prepare(G.minus(site,surface)));
      if(!room.fits(triangle)||Array.from(taken.near(box)).some(other=>G.overlap(triangle,other))){limits.clearance++;continue;}
      const center=add(begin,left(u),Math.sign(turn)*r);
      const start=Math.atan2(begin[1]-center[1],begin[0]-center[0]);
      // Keep the chord error below 5 mm for all radii, including outside kerbs.
      const step=Math.min(Math.PI/36,2*Math.acos(1-.005/r));
      const n=Math.max(2,Math.ceil(sweep/step)),points=[begin];
      for(let j=1;j<n;j++){
        const a=start+turn*j/n;
        points.push(add(center,[Math.cos(a),Math.sin(a)],r));
      }
      points.push(end);
      taken.put(box,triangle);used[prev]+=trim;used[i]+=trim;
      turns[i]=points;arcs.push({...corner,points,bulge:Math.tan(turn/4)});
      if(corner.inner)innerBends.add(corner.node);
    }
    const rounded=rings.map(({points:ring,turns})=>{
      const points=ring.flatMap((p,i)=>turns[i]||[p]);
      return points.filter((p,i)=>dist(p,points[(i+points.length-1)%points.length])>1e-7);
    });
    return {surface:rounded,arcs,limits,unrounded:limits.short+limits.clearance+limits.transition};
  }
  function roadGeometry(f,all,graph,portInfo,w){
    const shapes=[],joints=new Map();
    for(const e of graph.edges){
      const width=e.width??all[e.owner].width??w;shapes.push(strip(graph.nodes[e.from],graph.nodes[e.to],width));
      for(const [n,other] of [[e.from,e.to],[e.to,e.from]]){
        if(!joints.has(n))joints.set(n,[]);
        joints.get(n).push({other,dir:unit(sub(graph.nodes[other],graph.nodes[n])),width});
      }
    }
    for(const [n,arms] of joints){
      if(n===graph.ports.entrance||n===graph.ports.exit)continue;
      const face=jointFace(graph.nodes[n],arms);
      if(face)shapes.push(face);
    }
    for(const [k,g] of Object.entries(portInfo))if(g.face&&graph.connected[k])shapes.push(g.face);
    const sharp=G.intersect(G.union(shapes),f.site);
    const {surface,arcs,unrounded,limits}=filletKerbs(sharp,f.site,cornerKeys(joints,graph));
    const byOwner=new Map();
    for(const e of graph.edges){if(!byOwner.has(e.owner))byOwner.set(e.owner,[]);byOwner.get(e.owner).push(e);}
    const runs=[];
    for(const [id,edges] of byOwner){
      const r=all[id],d=unit(sub(r.b,r.a));
      const spans=edges.map(e=>{
        const a=dot(sub(graph.nodes[e.from],r.a),d),b=dot(sub(graph.nodes[e.to],r.a),d);
        return {lo:Math.min(a,b),hi:Math.max(a,b),sign:e.twoWay===false&&a>b?-1:1,
          width:e.width??r.width??w,twoWay:e.twoWay??true,primary:e.primary??false};
      }).sort((a,b)=>a.lo-b.lo);
      const chain=[];
      for(const s of spans){
        const end=chain.at(-1);
        if(end&&end.sign===s.sign&&end.width===s.width&&end.twoWay===s.twoWay&&end.primary===s.primary&&s.lo-end.hi<.005)end.hi=s.hi;
        else chain.push(s);
      }
      for(const s of chain){
        const a=add(r.a,d,s.lo),b=add(r.a,d,s.hi);
        runs.push({a:s.sign>0?a:b,b:s.sign>0?b:a,role:r.role,id,width:s.width,twoWay:s.twoWay,primary:s.primary});
      }
    }
    const dead=[...joints].filter(([i,arms])=>arms.length===1&&i!==graph.ports.entrance&&i!==graph.ports.exit).length;
    return {graph,portInfo,surface,runs,dead,axes:all,arcs,unrounded,limits};
  }
  return {frame,angles,crossSpacing,kerbRadius,pattern,assemble,roadGeometry,roles,nearestEdge,mainMouth,withGateMains,connectGateTrunks,returnCandidates,mainCircuit};
}
globalThis.createParkingRoads=createParkingRoads;
