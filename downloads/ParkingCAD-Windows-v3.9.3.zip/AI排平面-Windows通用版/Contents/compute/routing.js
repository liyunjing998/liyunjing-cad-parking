/* Distances and displayed routes use the same directed centre-line graph and bay frontage. */
function createParkingRouting(G){
  function tree(nodes,adj,start){
    const distance=nodes.map(()=>Infinity),parent=nodes.map(()=>-1),done=new Uint8Array(nodes.length);
    distance[start]=0;
    for(;;){
      let u=-1,best=Infinity;
      for(let i=0;i<nodes.length;i++)if(!done[i]&&distance[i]<best){u=i;best=distance[i];}
      if(u===-1)break;
      done[u]=1;
      for(const [v,cost] of adj[u])if(best+cost<distance[v]){
        distance[v]=best+cost;parent[v]=u;
      }
    }
    return {distance,parent};
  }
  function prepare(graph,direction){
    const {nodes,edges,ports,connected}=graph;
    if(!connected.entrance||!connected.exit)return null;
    const forward=nodes.map(()=>[]),reverse=nodes.map(()=>[]),byRoad=new Map();
    for(const edge of edges){
      const {from:u,to:v,owner}=edge,length=G.dist(nodes[u],nodes[v]);
      forward[u].push([v,length]);reverse[v].push([u,length]);
      if(edge.twoWay??(direction!=='oneway')){forward[v].push([u,length]);reverse[u].push([v,length]);}
      if(!byRoad.has(owner))byRoad.set(owner,[]);byRoad.get(owner).push(edge);
    }
    const enter=tree(nodes,forward,ports.entrance),exit=tree(nodes,reverse,ports.exit);
    function access(front){
      if(!front)return null;
      let arrival=Infinity,departure=Infinity,inNode,outNode;
      for(const edge of byRoad.get(front.road)||[]){
        const a=nodes[edge.from],b=nodes[edge.to],p=G.on(a,b,front.p).p;
        if(G.dist(p,front.p)>.01)continue;
        const both=edge.twoWay??(direction!=='oneway');
        for(const n of [edge.from,edge.to]){
          const gap=G.dist(front.p,nodes[n]);
          if((both||n===edge.from||gap<.0001)&&enter.distance[n]+gap<arrival){arrival=enter.distance[n]+gap;inNode=n;}
          if((both||n===edge.to||gap<.0001)&&exit.distance[n]+gap<departure){departure=exit.distance[n]+gap;outNode=n;}
        }
      }
      return Number.isFinite(arrival+departure)?{arrival,departure,inNode,outNode}:null;
    }
    function chain(parent,n){
      const points=[];for(;n!==-1;n=parent[n])points.push(nodes[n]);return points;
    }
    function route(front,index){
      const a=access(front);if(!a)return null;
      const unique=points=>points.filter((p,i)=>!i||G.dist(points[i-1],p)>.00001);
      return {index,front:front.p,
        enter:{points:unique([...chain(enter.parent,a.inNode).reverse(),front.p]),length:a.arrival},
        exit:{points:unique([front.p,...chain(exit.parent,a.outNode)]),length:a.departure}};
    }
    return {access,route};
  }
  function measure(graph,frontages,direction){
    const paths=prepare(graph,direction);let count=0,total=0,longest=0,farIndex=-1;
    if(paths)frontages.forEach((front,i)=>{
      const a=paths.access(front);if(!a)return;
      const trip=a.arrival+a.departure;count++;total+=trip;
      if(farIndex<0||trip>longest){farIndex=i;longest=trip;}
    });
    return {reachable:count,meanTrip:count?total/count:null,longestTrip:count?longest:null,farIndex};
  }
  return {measure,route:(state,index)=>prepare(state.graph,state.direction)?.route(state.frontages[index],index)||null,
    farBay:state=>state.stats.farIndex??measure(state.graph,state.frontages,state.direction).farIndex};
}
globalThis.createParkingRouting=createParkingRouting;
globalThis.ParkingRouting=createParkingRouting(createParkingGeometry(globalThis.ClipperLib));
