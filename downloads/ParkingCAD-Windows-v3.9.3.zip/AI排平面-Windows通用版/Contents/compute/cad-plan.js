/* The native panel, DXF and portable bridge share the same drawing in metres. */
function createParkingCadPlan(G){
  const {sub,add,dot,cross,left,unit,dist}=G,pi=Math.PI,tau=2*pi;
  const layerNames=['STALL','GREEN','ROUTE','PORT','TREE','METRICS','PAVE','CURB','WALL','DIMS'];
  const scaleOf={m:[6,1],cm:[5,100],mm:[4,1000]};
  const vtx=(p,b=0)=>[p[0],p[1],b];
  function network(graph){
    const nodes=graph.nodes,adj=nodes.map(()=>[]),edges=[],seen=new Set();
    for(const e of graph.edges){
      const a=e.from,b=e.to,k=a<b?a+'/'+b:b+'/'+a;
      if(a===b||seen.has(k)||dist(nodes[a],nodes[b])<.00001)continue;
      seen.add(k);const id=edges.length;edges.push([a,b]);adj[a].push(id);adj[b].push(id);
    }
    const other=(i,n)=>edges[i][0]===n?edges[i][1]:edges[i][0],links=nodes.map(()=>new Map());
    adj.forEach((ids,n)=>{
      function pair(x,y){links[n].set(x,y);links[n].set(y,x);}
      if(ids.length===2){pair(...ids);return;}
      const choices=[];
      for(let i=0;i<ids.length;i++)for(let j=i+1;j<ids.length;j++){
        const x=ids[i],y=ids[j],cos=dot(unit(sub(nodes[other(x,n)],nodes[n])),unit(sub(nodes[other(y,n)],nodes[n])));
        if(cos<-.99996)choices.push([cos,x,y]);
      }
      choices.sort((a,b)=>a[0]-b[0]);for(const [,x,y] of choices)if(!links[n].has(x)&&!links[n].has(y))pair(x,y);
    });
    const used=new Set(),chains=[];
    function walk(n,e){
      const ids=[n];while(e!==undefined&&!used.has(e)){used.add(e);n=other(e,n);ids.push(n);e=links[n].get(e);}
      const closed=ids.length>2&&ids[0]===ids.at(-1);if(closed)ids.pop();chains.push({ids,closed});
    }
    for(const [n,ids] of adj.entries())for(const e of ids)if(!used.has(e)&&!links[n].has(e))walk(n,e);
    for(const [e,[n]] of edges.entries())if(!used.has(e))walk(n,e);
    return {adj,chains};
  }
  function curves(surface){
    const road=G.prepare(surface),boundary=new G.Index(12);
    for(const r of surface)r.forEach((a,i)=>{const b=r[(i+1)%r.length];boundary.put(G.bounds([a,b]),[a,b]);});
    function fits(center,r,start,turn,point){
      const sign=Math.sign(turn),sweep=Math.abs(turn),cuts=[0,sweep],mod=a=>(a%tau+tau)%tau;
      const boxPts=[point(0),point(sweep)];
      for(let i=0;i<4;i++){const rel=mod(sign*(i*pi/2-start));if(rel<sweep)boxPts.push(point(rel));}
      for(const [a,b] of boundary.near(G.bounds(boxPts))){
        const d=sub(b,a),v=sub(a,center),aa=dot(d,d),bb=dot(v,d),cc=dot(v,v)-r*r;
        if(aa<1e-14)continue;
        const disc=bb*bb-aa*cc;if(disc<0)continue;
        for(const u of [(-bb-Math.sqrt(disc))/aa,(-bb+Math.sqrt(disc))/aa]){
          if(u<0||u>1)continue;
          const hit=add(v,d,u),alpha=mod(sign*(Math.atan2(hit[1],hit[0])-start));
          if(alpha>0&&alpha<sweep)cuts.push(alpha);
        }
      }
      cuts.sort((a,b)=>a-b);
      return road.has(point(0))&&road.has(point(sweep))&&cuts.slice(1).every((end,i)=>road.has(point((cuts[i]+end)/2)));
    }
    return function arc(a,b,c,desired,roomA=dist(a,b)*.48,roomB=dist(b,c)*.48){
      const u=unit(sub(b,a)),v=unit(sub(c,b)),turn=Math.atan2(cross(u,v),dot(u,v)),sweep=Math.abs(turn);
      if(sweep<pi/36||sweep>pi*.96)return null;
      const tangent=Math.tan(sweep/2),max=Math.min(roomA,roomB)/tangent;
      function at(r){
        const begin=add(b,u,-r*tangent),end=add(b,v,r*tangent),center=add(begin,left(u),Math.sign(turn)*r);
        const start=Math.atan2(begin[1]-center[1],begin[0]-center[0]);
        const point=angle=>[center[0]+r*Math.cos(start+Math.sign(turn)*angle),center[1]+r*Math.sin(start+Math.sign(turn)*angle)];
        return fits(center,r,start,turn,point)?{begin,end,bulge:Math.tan(turn/4),r,mid:point(sweep/2)}:null;
      }
      if(desired)return desired<=max+.000001?at(desired):null;
      // Short tangent allocations keep successive bends from consuming the same straight segment.
      let lo=0,hi=max;
      if(at(hi))lo=hi;
      else for(let i=0;i<13;i++){const r=(lo+hi)/2;if(at(r))lo=r;else hi=r;}
      const quantized=Math.floor((lo+1e-7)*10)/10;return quantized>=.1?at(quantized):null;
    };
  }
  function indicatorTable(s,scheme){
    const a=ParkingEngine.areaSchedule(s.stats.surfaceAreas);
    const rows=[
      ['指标','数值','单位'],
      ['总用地面积',a.total.toFixed(2),'m²'],
      ['铺装面积',a.paved.toFixed(2),'m²'],
      ['绿地面积',a.green.toFixed(2),'m²'],
      ['车位总面积',a.stalls.toFixed(2),'m²'],
      ['停车位数',String(s.stats.spaces),'个'],
      ['绿地率',(s.stats.surfaceAreas.green*100/s.stats.surfaceAreas.total).toFixed(2),'%']
    ];
    if(a.pending>0)rows.splice(5,0,['待定用地',a.pending.toFixed(2),'m²']);
    if(s.wallWidth)rows.push(['红线内墙占地',a.wall.toFixed(2),'m²']);
    if(s.curbWidth)rows.splice(3,0,['其中路缘石',s.stats.curbArea.toFixed(2),'m²']);
    const {x1,y1}=G.bounds(s.zone.boundary);
    const textHeight=.9, rowHeight=1.9, headingHeight=2.4;
    const valueWidth=Math.max(5.4,1.1+Math.max(...rows.map(row=>row[1].length))*.78);
    const x=[x1+3,x1+10.1,x1+10.1+valueWidth,x1+13.5+valueWidth];
    const top=y1, header=top-headingHeight, bottom=header-rows.length*rowHeight, items=[];
    function line(points,closed=false){items.push({layer:'METRICS',kind:'P',closed,vertices:points.map(p=>vtx(p))});}
    function text(p,height,value){items.push({layer:'METRICS',kind:'T',p,height,value});}
    line([[x[0],top],[x[3],top],[x[3],bottom],[x[0],bottom]],true);
    for(const column of x.slice(1,-1))line([[column,header],[column,bottom]]);
    const suffix=/^[ABC]$/.test(scheme||'')?' · 方案 '+scheme:'';
    text([x[0]+.52,header+.58],1.06,'经济技术指标表'+suffix);
    rows.forEach((cells,i)=>{
      const y=header-i*rowHeight;
      line([[x[0],y],[x[3],y]]);
      cells.forEach((value,j)=>text([x[j]+.46,y-rowHeight+.49],textHeight,value));
    });
    const groups=ParkingEngine.stallGroups(s);
    const y0=bottom-2.1;
    function legendText(x,y,value){items.push({layer:'METRICS',kind:'T',p:[x,y],height:.9,value,legend:true});}
    legendText(x[0],y0,'车位规格图例 · 米');
    groups.forEach(({label,color,rings},i)=>{
      const y=y0-(i+1)*rowHeight;
      items.push({layer:'METRICS',kind:'P',closed:true,vertices:[[x[0],y],[x[0]+1.6,y],[x[0]+1.6,y+1],[x[0],y+1]].map(p=>vtx(p)),
        pen:parseInt(color.slice(1),16),legend:true});
      legendText(x[0]+2.2,y,label+'  '+rings.length+'辆');
    });
    return items;
  }
  function roadWidths(s){
    const segments=new G.Index(12),used=[];
    for(const ring of s.roadSurface)ring.forEach((a,i)=>{
      const b=ring[(i+1)%ring.length];segments.put(G.bounds([a,b]),[a,b]);
    });
    // Measure between opposite edges on a clear straight. Intersections are wider
    // than the aisle they serve and do not represent its normal clear width.
    for(const run of s.runs.slice().sort((a,b)=>dist(b.a,b.b)-dist(a.a,a.b))){
      if(dist(run.a,run.b)<2)continue;
      const width=run.width??s.aisleWidth;
      const along=unit(sub(run.b,run.a)),normal=left(along);
      for(const fraction of [.5,.34,.66,.2,.8]){
        const center=G.lerp(run.a,run.b,fraction);
        if(used.some(d=>dist(d.center,center)<(Math.abs(d.width-width)<.015?1.35:.65)*width))continue;
        const a=add(center,normal,-width),b=add(center,normal,width),hits=[];
        for(const [u,v] of segments.near(G.bounds([a,b]))){
          const hit=G.cuts(a,b,u,v);if(hit)hits.push(dot(sub(hit.p,center),normal));
        }
        const lo=Math.max(...hits.filter(n=>n<0)),hi=Math.min(...hits.filter(n=>n>0));
        if(Math.abs(hi-lo-width)>.015)continue;
        used.push({center,along,a:add(center,normal,lo),b:add(center,normal,hi),width:hi-lo});break;
      }
    }
    return used;
  }
  // Polygon clipping may start a closed ring halfway along an arc or insert
  // a point on one of its chords. Keep editable arcs only for complete runs.
  function roadVertices(s){
    const tol=.00015,starts=new G.Index(8);
    function register(points,bulge){
      const [x,y]=points[0];
      starts.put({x0:x-tol,y0:y-tol,x1:x+tol,y1:y+tol},{points,bulge});
    }
    for(const arc of s.kerbArcs||[])register(arc.points,arc.bulge);
    if(!s.curbWidth)for(const bed of s.greenBeds||[])for(const ring of bed.curves||[]){
      ring.forEach((p,i)=>{
        if(!p[2])return;
        const end=vtx(ring[(i+1)%ring.length]);
        register(G.sampleGrassRing([p,end]).reverse(),-p[2]);
      });
    }
    return function vertices({points,closed}){
      const n=points.length,matches=new Map();let start=0;
      points.forEach((p,i)=>{
        for(const arc of starts.near(G.bounds([p]))){
          const ref=arc.points;
          if(dist(p,ref[0])>tol)continue;
          let j=1,steps=0,t=0;
          while(j<ref.length&&steps<(closed?n-1:n-i-1)){
            const q=points[(i+steps+1)%n];
            if(dist(q,ref[j])<=tol){j++;t=0;}
            else{
              const hit=G.on(ref[j-1],ref[j],q);
              if(dist(hit.p,q)>tol||hit.t+1e-5<t)break;
              t=hit.t;
            }
            steps++;
          }
          if(j<ref.length)continue;
          matches.set(i,{steps,bulge:arc.bulge});
          if(closed&&i+steps>n)start=i;
          break;
        }
      });
      const out=[];
      for(let offset=0;offset<n;){
        const i=(start+offset)%n,match=matches.get(i);
        out.push(vtx(points[i],match?.bulge||0));
        offset+=match?.steps||1;
      }
      return out;
    };
  }
  function plan(s,options={}){
    const items=[],notes={radii:[],unrounded:0};
    const poly=(layer,vertices,closed,outline=false,strokeWidth=0)=>{if(vertices.length>=(closed?3:2))items.push({layer,kind:'P',closed,vertices,outline,...(strokeWidth?{strokeWidth}:{})});};
    const plain=(layer,points,closed=true,outline=false)=>poly(layer,points.map(p=>vtx(p)),closed,outline);
    const label=(layer,p,height,value)=>items.push({layer,kind:'T',p,height,value});
    const marks=G.planOutlines(s);
    for(const [layer,regions,rgb] of [['PAVE',marks.hardscape,0xb6afa3],['CURB',marks.curb,0x9a968a],['WALL',marks.wall,0x786e69]]){
      for(const rings of regions)items.push({layer,kind:'H',rings,rgb});
    }
    for(const group of ParkingEngine.stallGroups(s)){
      for(const r of group.insets)items.push({layer:'STALL',kind:'P',closed:true,vertices:r.map(p=>vtx(p)),pen:parseInt(group.color.slice(1),16)});
    }
    const lawnCurves=new Map();
    for(const [i,rings] of marks.planting.entries()){
      const curves=s.greenBeds?.[i]?.curves;
      const hatch={layer:'GREEN',kind:'H',rings};
      if(curves?.some(r=>r.some(v=>v[2]))){
        hatch.curves=curves;
        rings.forEach((r,j)=>lawnCurves.set(r,curves[j]));
      }
      items.push(hatch);
    }
    const roadBoundary=roadVertices(s);
    for(const [layer,paths] of [['GREEN',marks.green],['ROUTE',marks.road],['STALL',marks.stalls]]){
      for(const mark of paths){
        if(layer==='GREEN'&&lawnCurves.has(mark.points)){
          poly(layer,lawnCurves.get(mark.points),true,true);continue;
        }
        if(layer==='ROUTE')poly(layer,roadBoundary(mark),mark.closed,true);
        else plain(layer,mark.points,mark.closed,true);
      }
    }
    for(const [layer,regions] of [['WALL',marks.wall],['CURB',marks.curb]]){
      for(const group of regions)for(const ring of group)plain(layer,ring);
    }
    for(const p of s.trees)items.push({layer:'TREE',kind:'I',...ParkingTrees.placement(p)});
    const {adj}=network(s.graph),nodes=s.graph.nodes,arc=curves(s.roadSurface);
    const desired=options.radius==null?0:Number(options.radius);
    const innerAt=new Map();
    for(const kerb of s.kerbArcs||[]){
      if(!kerb.inner)continue;
      if(!innerAt.has(kerb.node))innerAt.set(kerb.node,[]);
      innerAt.get(kerb.node).push(kerb);
    }
    const key=p=>p.map(n=>Math.round(n*1000)).join(',');
    const nodeIds=new Map(nodes.map((p,i)=>[key(p),i]));
    const checkBand=G.laneProbe(s.green||[]),checkRoad=G.laneProbe(s.roadSurface,{outside:true});
    const arms=nodes.map(()=>[]);
    for(const e of s.graph.edges){
      const width=e.width??s.aisleWidth;
      arms[e.from].push({id:e.to,width,in:e.twoWay!==false,out:true});
      arms[e.to].push({id:e.from,width,in:true,out:e.twoWay!==false});
    }
    const inspected=new Map(),conflicts=[];
    const clearance=notes.clearance={width:5,segments:[],checked:0,touch:0,overlap:0,unresolved:0,conflicts};
    function record(tag,hit,a,b,bulge=0){
      if(inspected.has(tag))return;
      inspected.set(tag,hit.status);
      if(hit.status==='unresolved'){clearance.unresolved++;return;}
      clearance.checked++;
      if(a&&b)clearance.segments.push({a,b,bulge,status:hit.status});
      if(hit.status==='clear')return;
      clearance[hit.status]++;
      conflicts.push({point:hit.point,status:hit.status});
    }
    function turningArc(a,p,b,roomA=dist(a,p),roomB=dist(b,p)){
      const directions=[a,b].map(q=>unit(sub(q,p)));
      if(dot(...directions)<-Math.cos(pi/36))return null;
      const tag='turn/'+[key(p),...directions.map(key).sort()].join('/');
      const id=nodeIds.get(key(p));
      const kerb=(innerAt.get(id)||[]).find(k=>k.arms.every(other=>
        directions.some(direction=>dot(direction,unit(sub(nodes[other],p)))>.999999)));
      const widths=directions.map(d=>(arms[id]||[]).find(e=>dot(d,unit(sub(nodes[e.id],p)))>.999999)?.width);
      const radius=desired||(kerb?kerb.radius+kerb.width/2:widths.every(w=>w>0)?5+(widths[0]+widths[1])/4:0);
      const turn=radius?arc(a,p,b,radius,roomA,roomB):null;
      if(!turn){record(tag,{status:'unresolved'});return null;}
      const hit=checkBand(turn.begin,turn.end,turn.bulge);
      if(hit.status==='clear'&&checkRoad(turn.begin,turn.end,turn.bulge).status==='overlap'){
        record(tag,{status:'unresolved'});return null;
      }
      record(tag,hit,turn.begin,turn.end,turn.bulge);
      return hit.status==='clear'?turn:null;
    }
    if(!Number.isFinite(desired)||desired<0)throw Error('绘图半径应为正数，或留空。');
    const registered=new Set();
    function radius(turn){
      const key=turn.mid.map(x=>Math.round(x*1000)).join(',');if(registered.has(key))return;registered.add(key);
      notes.radii.push(turn.r);
      if(desired)label('ROUTE',add(turn.mid,[.36,.36]),.75,'R'+Number(turn.r.toFixed(3)));
    }
    const chains=[];
    for(const group of ['trunk','loop','service']){
      const edges=s.graph.edges.filter(e=>(e.trunk?'trunk':e.primary?'loop':'service')===group);
      for(const chain of network({nodes,edges}).chains)chains.push({...chain,wide:group!=='service'});
    }
    for(const {ids,closed,wide} of chains){
      const stops=ids.filter((id,i)=>{
        if(!closed&&(i===0||i===ids.length-1))return true;
        const p=nodes[id],a=nodes[ids[(i+ids.length-1)%ids.length]],b=nodes[ids[(i+1)%ids.length]];
        return dot(unit(sub(p,a)),unit(sub(b,p)))<=.9999999;
      });
      const vertices=[],n=stops.length,used=stops.map(()=>0);
      for(let i=0;i<n;i++){
        const prev=(i+n-1)%n,id=stops[i],p=nodes[id],a=nodes[stops[prev]],b=nodes[stops[(i+1)%n]];
        if((closed||i>0&&i<n-1)&&adj[id].length===2){
          const t=turningArc(a,p,b,dist(a,p)-used[prev],dist(p,b)-used[i]);
          if(t){
            if(vertices.length&&dist(vertices.at(-1),t.begin)<1e-7)vertices.pop();
            vertices.push(vtx(t.begin,t.bulge),vtx(t.end));
            used[prev]+=dist(t.begin,p);used[i]+=dist(t.end,p);radius(t);continue;
          }
          if(dot(unit(sub(p,a)),unit(sub(b,p)))<Math.cos(pi/36))notes.unrounded++;
        }
        if(!vertices.length||dist(vertices.at(-1),p)>1e-7)vertices.push(vtx(p));
      }
      if(closed&&vertices.length>1&&dist(vertices[0],vertices.at(-1))<1e-7)vertices.pop();
      for(let i=0;i<vertices.length-Number(!closed);i++){
        const a=vertices[i],b=vertices[(i+1)%vertices.length];
        if(!a[2])record('line/'+[key(a.slice(0,2)),key(b.slice(0,2))].sort().join('/'),checkBand(a.slice(0,2),b.slice(0,2)),a.slice(0,2),b.slice(0,2));
      }
      poly('ROUTE',vertices,closed,false,wide ? .42 : 0);
    }
    // Add only the actual turning movements of the chosen trip at branching junctions.
    const ref=options.bayIndex??ParkingRouting.farBay(s),trip=ParkingRouting.route(s,ref);
    const junctions=new Set(nodes.filter((p,i)=>adj[i].length>2).map(key)),moves=new Set();
    for(const path of trip?[trip.enter.points,trip.exit.points]:[]){
      for(let i=1;i+1<path.length;i++){const [a,p,b]=path.slice(i-1,i+2);if(!junctions.has(key(p)))continue;
        const tags=[key(unit(sub(a,p))),key(unit(sub(b,p)))].sort(),id=[key(p),...tags].join('/');
        if(moves.has(id))continue;moves.add(id);
        const t=turningArc(a,p,b);
        if(t){poly('ROUTE',[vtx(t.begin,t.bulge),vtx(t.end)],false);radius(t);}
        else if(dot(unit(sub(p,a)),unit(sub(b,p)))<Math.cos(pi/36))notes.unrounded++;
      }
    }
    // Inspect the other legal turning movements as well as the displayed trip.
    for(const [id,list] of arms.entries())if(list.length>=2){
      for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
        const a=list[i],b=list[j];
        if(a.in&&b.out||b.in&&a.out)turningArc(nodes[a.id],nodes[id],nodes[b.id]);
      }
    }
    const marked=new Set();
    for(const {point:[x,y],status} of conflicts){
      const tag=key([x,y]);if(marked.has(tag))continue;marked.add(tag);
      items.push({inspection:true,kind:'P',layer:'METRICS',closed:true,pen:status==='overlap'?0xe83c31:0xf2a32b,
        vertices:[[x-.55,y],[x,y-.55],[x+.55,y],[x,y+.55]].map(p=>vtx(p))});
    }
    for(const e of s.graph.edges){
      if(e.twoWay!==false)continue;
      const a=nodes[e.from],b=nodes[e.to],length=dist(a,b);
      if(length<3)continue;
      const dir=unit(sub(b,a)),normal=left(dir),mid=G.lerp(a,b,.5);
      const size=Math.min(1.4,length*.12);
      plain('ROUTE',[add(add(mid,dir,-size),normal,.6*size),add(mid,dir,size),add(add(mid,dir,-size),normal,-.6*size)],false);
    }
    for(const d of roadWidths(s)){
      plain('DIMS',[d.a,d.b],false);
      const tick=unit(add(d.along,left(d.along)));
      for(const p of [d.a,d.b])plain('DIMS',[add(p,tick,-.36),add(p,tick,.36)],false);
      label('DIMS',add(d.center,[.35,.45]),.82,d.width.toFixed(1)+' m');
    }
    const {entrance,exit}=s.zone,both=entrance&&exit&&dist(entrance,exit)<.004;
    for(const [kind,p] of [['entrance',entrance],['exit',exit]]){
      if(!p||both&&kind==='exit')continue;
      const edge=s.zone.boundary.reduce((best,a,i)=>{const b=s.zone.boundary[(i+1)%s.zone.boundary.length],hit=G.on(a,b,p),d=dist(p,hit.p);return !best||d<best.d?{a,b,d}:best;},null);
      const port=s.graph.ports[kind],main=s.graph.edges.find(e=>e.role==='main'&&(e.from===port||e.to===port));
      const n=left(unit(sub(edge.b,edge.a)));
      const inward=main?unit(sub(nodes[main.from===port?main.to:main.from],p)):
        (G.signed(s.zone.boundary)>0?n:n.map(x=>-x));
      const tangent=left(inward);
      const arrow=dir=>plain('PORT',[add(add(p,inward,-1.2*dir),tangent,-.7),add(p,inward,1.05*dir),add(add(p,inward,-1.2*dir),tangent,.7)],false);
      if(both){plain('PORT',[add(p,inward,1.3),add(p,tangent,.65),add(p,inward,-1.3),add(p,tangent,-.65)]);}
      else arrow(kind==='entrance'?1:-1);
      const name=both?'IN/OUT':kind==='entrance'?'IN':'OUT';label('PORT',add(p,inward,-2.3),1.15,name);
    }
    if(s.stalls.length)items.push(...indicatorTable(s,options.scheme));
    return {items,notes};
  }
  function bandItems(notes){
    return notes.clearance.segments.map(({a,b,bulge,status})=>{
      const d=sub(b,a),normal=left(unit(d)),half=notes.clearance.width/2;
      let vertices;
      if(!bulge)vertices=G.strip(a,b,2*half).map(p=>vtx(p));
      else {
        const center=add(G.lerp(a,b,.5),normal,dist(a,b)*(1-bulge*bulge)/(4*bulge));
        const u=unit(sub(a,center)),v=unit(sub(b,center));
        vertices=[vtx(add(a,u,-half),bulge),vtx(add(b,v,-half)),vtx(add(b,v,half),-bulge),vtx(add(a,u,half))];
      }
      return {kind:'P',layer:'METRICS',closed:true,vertices,pen:status==='clear'?0x74b8d4:status==='overlap'?0xe83c31:0xf2a32b};
    });
  }
  function dxf(items,unitName='m'){
    const tpl=ParkingCadTemplate,[units,k]=scaleOf[unitName]||scaleOf.m,body=[];
    const add=(...v)=>body.push(...v),num=n=>Number((n*k).toFixed(8));let handle=tpl.first;
    let xmin=Infinity,ymin=Infinity,xmax=-Infinity,ymax=-Infinity;
    function include(x,y){xmin=Math.min(xmin,x);ymin=Math.min(ymin,y);xmax=Math.max(xmax,x);ymax=Math.max(ymax,y);}
    function start(type,layer,subclass,outline=false,rgb,pen,id,reactor){
      add(0,type,5,id||alloc());
      if(reactor)add(102,'{ACAD_REACTORS',330,reactor,102,'}');
      add(330,tpl.owner,100,'AcDbEntity',8,'PARK-'+layer);
      if(outline)add(6,'CONTINUOUS',62,7,370,13);
      if(pen!==undefined)add(420,pen,370,13);
      if(rgb!==undefined)add(420,rgb,440,0x02000000+128);
      add(100,subclass);
    }
    const records=[],blocks=[];
    const alloc=()=>(handle++).toString(16).toUpperCase();
    const handles=new Map(),greenLoops=new Map(),references=new Map(),reactors=new Map();
    const loopKey=r=>JSON.stringify(r.map(([x,y,b=0])=>[x,y,b]));
    for(const e of items)if(e.layer==='GREEN'&&e.kind==='P'&&e.closed&&e.outline){
      handles.set(e,alloc());greenLoops.set(loopKey(e.vertices),e);
    }
    for(const e of items)if(e.layer==='GREEN'&&e.kind==='H'){
      const loops=(e.curves||e.rings).map(r=>greenLoops.get(loopKey(r)));
      if(loops.length&&loops.every(Boolean)){
        handles.set(e,alloc());references.set(e,loops.map(p=>handles.get(p)));
        for(const p of loops)reactors.set(p,handles.get(e));
      }
    }
    const treeStyles=new Set(items.filter(e=>e.kind==='I').map(e=>e.style));
    for(const style of treeStyles){
      const owner=alloc(),name=ParkingTrees.names[style];
      records.push(0,'BLOCK_RECORD',5,owner,330,'9',100,'AcDbSymbolTableRecord',100,'AcDbBlockTableRecord',2,name,70,0,280,1,281,0);
      const part=(type,subclass)=>blocks.push(0,type,5,alloc(),330,owner,100,'AcDbEntity',8,'0',100,subclass);
      part('BLOCK','AcDbBlockBegin');blocks.push(2,name,70,0,10,0,20,0,30,0,3,name,1,'');
      for(const [a,b] of ParkingTrees.styles[style]){
        part('LINE','AcDbLine');blocks.push(10,a[0],20,a[1],30,0,11,b[0],21,b[1],31,0);
      }
      part('ENDBLK','AcDbBlockEnd');
    }
    for(const e of items){
      if(e.kind==='I'){
        const [x,y]=e.p,r=ParkingTrees.radius*e.scale;
        include(x-r,y-r);include(x+r,y+r);
        // Unitless block geometry is in metres. Convert its reference scale once.
        add(0,'INSERT',5,alloc(),330,tpl.owner,100,'AcDbEntity',8,'PARK-TREE',62,7,370,9,100,'AcDbBlockReference',
          2,ParkingTrees.names[e.style],10,num(x),20,num(y),30,0,41,k*e.scale,42,k*e.scale,43,k*e.scale,50,e.angle*180/pi);
      }else if(e.kind==='P'){
        start('LWPOLYLINE',e.layer,'AcDbPolyline',e.outline,undefined,e.pen,handles.get(e),reactors.get(e));add(90,e.vertices.length,70,e.closed?1:0);
        if(e.strokeWidth)add(43,num(e.strokeWidth));
        for(let i=0;i<e.vertices.length;i++){
          const [x,y,b]=e.vertices[i];include(x,y);add(10,num(x),20,num(y));
          if(b){
            add(42,b);
            const next=e.vertices[(i+1)%e.vertices.length],margin=Math.abs(b)*Math.hypot(next[0]-x,next[1]-y)/2;
            include(Math.min(x,next[0])-margin,Math.min(y,next[1])-margin);
            include(Math.max(x,next[0])+margin,Math.max(y,next[1])+margin);
          }
        }
      }else if(e.kind==='T'){
        include(...e.p);include(e.p[0]+e.value.length*e.height,e.p[1]+e.height);
        const value=e.layer==='PORT'?({IN:'入口',OUT:'出口','IN/OUT':'出入口'}[e.value]||e.value):e.value;
        start('TEXT',e.layer,'AcDbText');add(10,num(e.p[0]),20,num(e.p[1]),30,0,40,num(e.height),1,value);
        if(e.layer==='METRICS'||e.layer==='PORT')add(7,'LYJ-PARK-METRICS');
        add(100,'AcDbText');
      }else{
        const refs=references.get(e);
        start('HATCH',e.layer,'AcDbHatch',false,e.layer==='GREEN'?0x83a775:e.rgb,undefined,handles.get(e));add(10,0,20,0,30,0,210,0,220,0,230,1,2,'SOLID',70,1,71,refs?1:0,91,e.rings.length);
        (e.curves||e.rings).forEach((r,i)=>{
          const curved=r.some(v=>v[2]);add(92,i===0?3:2,72,curved?1:0,73,1,93,r.length);
          for(const [x,y,b=0] of r){include(x,y);add(10,num(x),20,num(y));if(curved)add(42,b);}
          add(97,refs?1:0);if(refs)add(330,refs[i]);
        });
        add(75,0,76,1,98,0);
      }
    }
    if(!Number.isFinite(xmin)){xmin=ymin=0;xmax=ymax=1;}
    const values={UNIT:units,NEXT:handle.toString(16).toUpperCase(),XMIN:num(xmin),YMIN:num(ymin),XMAX:num(xmax),YMAX:num(ymax),
      CX:num((xmin+xmax)/2),CY:num((ymin+ymax)/2),VIEW_HEIGHT:num(1.12*Math.max(.1,ymax-ymin,(xmax-xmin)/1.34)),ENTITIES:body.join('\n')};
    let template=tpl.template;
    if(records.length){
      template=template.replace(/(0\nTABLE\n2\nBLOCK_RECORD[\s\S]*?\n70\n)2\n/,(_,head)=>head+(2+treeStyles.size)+'\n')
        .replace('0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nBLOCKS',records.join('\n')+'\n$&')
        .replace('0\nENDSEC\n0\nSECTION\n2\nENTITIES',blocks.join('\n')+'\n$&');
    }
    return template.replace(/__([A-Z_]+)__/g,(_,field)=>String(values[field])).replace(/\n/g,'\r\n');
  }
  return {plan,bandItems,dxf,layerNames,roadWidths};
}
globalThis.ParkingCadPlan=createParkingCadPlan(createParkingGeometry(ClipperLib));
