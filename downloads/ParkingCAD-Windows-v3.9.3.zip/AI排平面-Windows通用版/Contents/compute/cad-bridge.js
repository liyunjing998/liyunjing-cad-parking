/* Plain text exchange for the portable AutoLISP importer. No executable code. */
(function (root) {
  'use strict';
  const number = n => {
    if (!Number.isFinite(n) || Math.abs(n)>1e9) throw Error('CAD 坐标超出支持范围。');
    return n.toFixed(6);
  };
  const polygon = poly => '(' + poly.map(p => `(${number(p[0])} ${number(p[1])})`).join(' ') + ')';
  const vertex=([x,y,b])=>'('+number(x)+' '+number(y)+' '+b.toFixed(10)+')';
  function serialize(layout) {
    if (!layout || !layout.aisles?.length) throw Error('当前没有可回写的通道。');
    const id = String(layout.zone.id||'P1').replace(/[^A-Za-z0-9_-]/g,'_').slice(0,24) || 'P1';
    const lines=['PARKING-RESULT-V1',id,'m',layout.version,polygon(layout.zone.boundary),String(layout.stalls.length)];
    for (const item of layout.stalls) lines.push(polygon(item));
    lines.push(String(layout.aisles.length));
    for (const item of layout.aisles) lines.push(polygon(item));
    lines.push('END');
    return lines.join('\n')+'\n';
  }
  function clean(layout,items){
    const id=String(layout.zone.id||'P1').replace(/[^A-Za-z0-9_-]/g,'_').slice(0,24)||'P1';
    const defined=new Set();
    const line=e=>{
      if(e.kind==='I'&&e.layer==='TREE'&&[0,1].includes(e.style)&&e.scale>=.7&&e.scale<=1.2){
        const paths=defined.has(e.style)?'nil':'('+ParkingTrees.styles[e.style].map(polygon).join(' ')+')';
        defined.add(e.style);
        return '("TREE" "I" '+e.style+' ('+e.p.map(number).join(' ')+') '+number(e.scale)+' '+number(e.angle)+' '+paths+')';
      }
      if(e.pen!==undefined && (e.kind!=='P'||!e.closed||!['STALL','METRICS'].includes(e.layer)||!Number.isInteger(e.pen)||e.pen<0||e.pen>0xffffff))throw Error('内框颜色无效。');
      if(!['STALL','GREEN','ROUTE','PORT','TREE','METRICS','PAVE','CURB','WALL','DIMS'].includes(e.layer)||
          !['P','H','T'].includes(e.kind)||(e.kind==='H'&&(e.layer==='GREEN'?e.rgb!==undefined:(!['STALL','PAVE','CURB','WALL','METRICS'].includes(e.layer)||!Number.isInteger(e.rgb)||e.rgb<0||e.rgb>0xffffff)))||
          (e.kind==='T'&&!['PORT','ROUTE','METRICS','DIMS'].includes(e.layer))||
          (e.outline&&!(e.kind==='P'&&['STALL','GREEN','ROUTE'].includes(e.layer)))){
        throw Error('此图元超出当前 CAD 插件的返还格式。请使用方案 DXF。');
      }
      if(e.strokeWidth!==undefined && (e.layer!=='ROUTE'||e.kind!=='P'||!Number.isFinite(e.strokeWidth)||e.strokeWidth<=0||e.strokeWidth>1))throw Error('主路绘图线宽无效。');
      const start='("'+e.layer+'" "'+(e.strokeWidth?'W':e.pen!==undefined?'K':e.kind==='P'&&e.outline?'B':e.kind)+'" ';
      if(e.kind==='P')return start+(e.closed?1:0)+' ('+e.vertices.map(vertex).join(' ')+')'+(e.strokeWidth?' '+number(e.strokeWidth):e.pen!==undefined?' '+e.pen:'')+')';
      if(e.kind==='H')return start+'('+(e.curves?e.curves.map(r=>'('+r.map(vertex).join(' ')+')'):e.rings.map(polygon)).join(' ')+')'+(e.rgb===undefined?'':' '+e.rgb)+')';
      if(e.layer==='METRICS'||e.layer==='DIMS'){
        if(!/^[\u4e00-\u9fffA-Za-z0-9 .%²·×°]{1,32}$/.test(e.value))throw Error('指标表文字无效。');
        return start+'('+e.p.map(number).join(' ')+') '+number(e.height)+' ('+Array.from(e.value,c=>c.charCodeAt(0)).join(' ')+'))';
      }
      if(!/^(?:IN|OUT|IN\/OUT|R[0-9]+(?:\.[0-9]+)?)$/.test(e.value))throw Error('图面标识格式无效。');
      return start+'('+e.p.map(number).join(' ')+') '+number(e.height)+' "'+e.value+'")';
    };
    if(items.length>100000||layout.zone.boundary.length>2048)throw Error('超过插件单批容量，请使用方案 DXF。');
    const version=items.some(e=>e.curves)?'PARKING-PLAN-V8':items.some(e=>e.strokeWidth)?'PARKING-PLAN-V7':items.some(e=>e.kind==='I'||e.pen!==undefined)?'PARKING-PLAN-V6':items.some(e=>e.rgb!==undefined)?'PARKING-PLAN-V5':items.some(e=>e.layer==='METRICS')?'PARKING-PLAN-V4':'PARKING-PLAN-V3';
    return [version,id,'m',polygon(layout.zone.boundary),String(items.length),...items.map(line),'END',''].join('\n');
  }
  function forSession(layout,items,source,key,shown=layout.zone,withMetrics=false,withFills=false,withBlocks=false,wideRoutes=false,curvedBeds=false){
    if(layout.exportable===false)throw Error('方案中有车位无法从入口驶入或驶往出口，请调整后再写回原图。');
    if(!/^[a-z0-9_-]{1,96}$/i.test(key||''))throw Error('请从 CAD 的 TCCSC 打开本次场地。');
    const matches=zone=>zone.id===source.id&&zone.boundary.length===source.boundary.length&&
      zone.boundary.every((point,i)=>point.every((v,j)=>Math.abs(v-source.boundary[i][j])<=.002));
    if(!matches(shown)||!matches(layout.zone)){
      throw Error('场地编号或边界已改变。请重新选择地块，或下载当前方案 DXF。');
    }
    const supported=items.filter(e=>(withBlocks||(e.kind!=='I'&&e.pen===undefined))&&(withMetrics||e.layer!=='METRICS')&&
      (withFills||(!e.legend&&e.rgb===undefined&&!['CURB','WALL','PAVE','DIMS'].includes(e.layer))));
    // Older importers accept straight hatch loops only. Send matching chorded
    // outlines and fills to them, so the loop association still works.
    const sampled=new Map();
    if(!curvedBeds)for(const e of supported)if(e.curves)
      e.curves.forEach((r,i)=>sampled.set(JSON.stringify(r),e.rings[i]));
    const compatible=supported.map(e=>{
      if(!curvedBeds&&e.curves)return {...e,curves:undefined};
      if(!curvedBeds&&e.layer==='GREEN'&&e.outline){
        const r=sampled.get(JSON.stringify(e.vertices));
        if(r)return {...e,vertices:r.map(([x,y])=>[x,y,0])};
      }
      return !wideRoutes&&e.strokeWidth?{...e,strokeWidth:undefined}:e;
    });
    return clean(layout,compatible)+'CAD-JOB '+key+'\n';
  }
  root.ParkingBridge={serialize,clean,forSession};
})(typeof window==='undefined'?globalThis:window);
