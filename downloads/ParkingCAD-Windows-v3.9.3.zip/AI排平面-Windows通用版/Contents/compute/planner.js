function createParkingPlanner(G,R) {
  'use strict';
  const routing=createParkingRouting(G);
  const {add,sub,dot,dist,unit,left,lerp,on,bounds,area,positive,union,minus,intersect,offset,disk,prepare}=G;
  // Measured intervals on a real, exposed kerb. A crossing or a gate breaks
  // the interval; the outer edge of a straight-sided bend can extend it.
  function kerbIntervals(surface,run,along,sideOffset){
    const normal=left(along),intervals=[];
    for(const ring of surface)for(let i=0;i<ring.length;i++){
      const a=sub(ring[i],run.a),b=sub(ring[(i+1)%ring.length],run.a);
      if(Math.abs(dot(a,normal)-sideOffset)>.00002||Math.abs(dot(b,normal)-sideOffset)>.00002)continue;
      const x=dot(a,along),y=dot(b,along);
      intervals.push([Math.min(x,y),Math.max(x,y)]);
    }
    const merged=[];
    for(const [lo,hi] of intervals.sort((a,b)=>a[0]-b[0])){
      const last=merged.at(-1);
      if(last&&lo<=last[1]+.00002)last[1]=Math.max(last[1],hi);
      else merged.push([lo,hi]);
    }
    return merged;
  }
  function stallLimitError(){
    return Object.assign(Error('轮廓大小错误'),{code:'STALL_LIMIT'});
  }
  function pack(frame,net,config,checkGaps=false,alignKerbs=false) {
    const {eco,parkingModes}=config;
    const free=prepare(minus(frame.site,config.lawn?union([...net.surface,...config.lawn]):net.surface)),occupied=new G.Index(9);
    const stalls=[],stallModes=[],stallSizes=[],frontages=[],treeIslands=[],blocks=[],rows=[],ends=[];
    const priority={row:0,infill:1,rim:2,cross:3,return:4};
    const runs=net.runs.filter(r=>r.role!=='gate'&&r.role!=='main').sort((a,b)=>Number(b.id===config.endRoad)-Number(a.id===config.endRoad)||priority[a.role]-priority[b.role]||dist(b.a,b.b)-dist(a.a,a.b));
    const road=alignKerbs&&prepare(net.surface),kerbs=new Map();
    function fill({mode,rule,size},gaps=false){
      const skew=rule.angle%90===0?0:rule.depth/Math.tan(Math.PI*rule.angle/180);
      for(const r of runs){
        const w=r.width;
        if(w+.00001<rule.operation)continue;
        const along=unit(sub(r.b,r.a)),L=dist(r.a,r.b);
        if(L<(alignKerbs?rule.pitch:rule.pitch+skew))continue;
        for(const side of [1,-1]){
          const n=left(along),depth=side*rule.depth,near=side*(w/2+.004);
          const travel=r.twoWay?-side:1;
          const lean=skew*travel*(rule.approach==='reverse'?-1:1);
          const start=add(add(r.a,n,near),along,alignKerbs?0:Math.max(0,-lean));
          const nCells=Math.floor((L-skew+.0001)/rule.pitch);
          const cell=(u,v)=>{const a=add(start,along,u),b=add(start,along,v);return [a,b,add(add(b,along,lean),n,depth),add(add(a,along,lean),n,depth)];};
          const slack=Math.max(0,L-skew-nCells*rule.pitch);
          function fits(p){
            for(const other of occupied.near(bounds(p)))if(G.overlap(p,other))return false;
            return free.fits(p);
          }
          function addRow(s,count){
            const e=s+count*rule.pitch;
            const block=positive(cell(s,e));blocks.push(block);occupied.put(bounds(block),block);
            const record={road:r.id,side,operation:rule.operation,capacity:0,a:add(start,along,s),b:add(start,along,e)};rows.push(record);
            for(const u of [s,e])ends.push({point:add(add(start,along,u+lean/2),n,depth/2),along});
            for(let k=0;k<count;k++){
              const u=s+k*rule.pitch,p=positive(cell(u,u+rule.pitch));
              if(eco&&count>=9&&(k===Math.floor(Math.min(11,count)/2)||k>5&&(k-5)%12===0)&&k<count-1){
                treeIslands.push(p);
              }else{
                if(stalls.length>=1500)throw stallLimitError();
                stalls.push(p);stallModes.push(mode);stallSizes.push(rule.angle===90?size:null);frontages.push({road:r.id,p:on(r.a,r.b,add(start,along,u+rule.pitch/2)).p});record.capacity++;
              }
            }
          }
          if(alignKerbs){
            if(!kerbs.has(r))kerbs.set(r,new Map());
            if(!kerbs.get(r).has(side))kerbs.get(r).set(side,kerbIntervals(net.surface,r,along,side*w/2));
            const pitch=rule.pitch;
            function fitsStation(u){
              if(!fits(cell(u,u+pitch)))return false;
              if(u>=0&&u+pitch<=L)return true;
              // At a junction a bay may straddle the centreline end station.
              // Verify its whole mouth faces a full aisle; its midpoint must
              // still project onto the serving edge of the directed graph.
              const a=add(r.a,along,u),b=add(a,along,pitch),half=side*(w/2-.0001);
              return road.fits([add(a,n,half),add(b,n,half),add(b,n,-half),add(a,n,-half)]);
            }
            for(const [lo,hi] of kerbs.get(r).get(side)){
              const first=Math.max(lo,-pitch/2),last=Math.min(hi-pitch,L-pitch/2);
              for(let u=first;u<=last+.000001;){
                let count=0;
                while(u+count*pitch<=last+.000001&&fitsStation(u+count*pitch))count++;
                if(count){addRow(u,count);u+=count*pitch;}
                else if(u>=last)break;
                else u=Math.min(last,u+.20);
              }
            }
            continue;
          }
          if(gaps){
            // A clipped row may leave space between two stations of the original pitch.
            const limit=L-skew-rule.pitch,step=.20;
            for(let u=0;u<limit+step-.000001;u+=step){
              const a=Math.min(u,limit),b=a+rule.pitch,p=positive(cell(a,b));
              if(!fits(p))continue;
              addRow(a,1);
              u=a+rule.pitch-step;
            }
            continue;
          }
          function possible(shift){
            const yes=[];
            for(let i=0;i<nCells;i++){
              const u=shift+i*rule.pitch;
              if(fits(cell(u,u+rule.pitch)))yes.push(i);
            }
            return yes;
          }
          let shift=slack/2,indices=possible(shift);
          // Try flush alignment at clipped short ends where half a pitch can cost a space.
          if(slack>.65 && nCells<=24){for(const q of [0,slack]){const trial=possible(q);if(trial.length>indices.length){indices=trial;shift=q;}}}
          let i=0;
          while(i<indices.length){
            let j=i+1;while(j<indices.length&&indices[j]===indices[j-1]+1)j++;
            addRow(shift+indices[i]*rule.pitch,j-i);
            i=j;
          }
        }
      }
    }
    for(const candidate of parkingModes)fill(candidate);
    if(checkGaps)for(const candidate of parkingModes)fill(candidate,true);
    return {stalls,stallModes,stallSizes,frontages,treeIslands,blocks,rows,ends};
  }
  function build(f,raw,config,kind,phase,crossShift=0){
    const net=R.assemble(f,raw,config.w,config.oneway,config),parking=pack(f,net,config);
    const travel=routing.measure(net.graph,parking.frontages,config.oneway?'oneway':'twoway');
    const gates=Number(net.graph.connected.entrance)+Number(net.graph.connected.exit);
    return {f,raw,net,parking,travel,gates,kind,phase,crossShift};
  }
  function sizeServiceAisles(plan,config,onlyWiden){
    const {net,parking,f}=plan,{nodes,edges}=net.graph,byOwner=new Map();
    for(const row of parking.rows){
      if(!row.capacity)continue;
      if(!byOwner.has(row.road))byOwner.set(row.road,[]);
      byOwner.get(row.road).push(row);
    }
    let changed=false;
    const sized=edges.map(e=>{
      if(e.primary)return e;
      const a=nodes[e.from],b=nodes[e.to],axis=unit(sub(b,a)),length=dist(a,b);
      let leftRow=false,rightRow=false,operation=0;
      for(const row of byOwner.get(e.owner)||[]){
        const x=dot(sub(row.a,a),axis),y=dot(sub(row.b,a),axis);
        if(Math.min(length,Math.max(x,y))-Math.max(0,Math.min(x,y))<.001)continue;
        if(G.cross(axis,sub(row.a,a))>0)leftRow=true;else rightRow=true;
        operation=Math.max(operation,row.operation);
      }
      const twoWay=e.bridge||(leftRow&&rightRow)||(onlyWiden&&e.twoWay);
      const width=Math.max(twoWay?config.branchWidth:5.5,operation,onlyWiden?e.width:0);
      if(e.width===width&&e.twoWay===twoWay)return e;
      changed=true;return {...e,width,twoWay};
    });
    return changed?R.roadGeometry(f,net.axes,{...net.graph,edges:sized},net.portInfo,config.w):net;
  }
  // Lexicographic order keeps a connected, usable extra bay ahead of any aesthetic preference.
  function compare(a,b){
    return b.gates-a.gates||Number(b.net.graph.connected.entrance)-Number(a.net.graph.connected.entrance)||b.travel.reachable-a.travel.reachable||
      b.parking.stalls.length-a.parking.stalls.length||a.net.dead-b.net.dead||
      (a.travel.meanTrip??Infinity)-(b.travel.meanTrip??Infinity)||area(a.net.surface)-area(b.net.surface);
  }
  function remainder(plan){return minus(plan.f.site,union([...plan.net.surface,...plan.parking.blocks]));}
  // Look for an under-used pocket enclosed by real aisles at the lot edge.
  // Its inner parking and the opposite edge row give the two treatments the
  // same site and accesses, independent of drawing orientation.
  function endPocket(plan,rule){
    const {net,parking,f}=plan,centres=parking.stalls.map(r=>lerp(r[0],r[2],.5));
    const bays=union(parking.stalls),candidates=[];
    for(const road of G.groups(net.surface))for(const hole of road.slice(1)){
      const cell=positive(hole),size=area([cell]);
      if(size<4*rule.pitch*rule.depth || !f.access.fits(cell))continue;
      const open=area(minus([cell],bays))/size;
      if(open<.28)continue;
      const inside=centres.map((p,i)=>G.inside(p,cell)?i:-1).filter(i=>i>=0);
      if(inside.length<2)continue;
      for(const r of net.runs.filter(r=>r.role==='rim')){
        const axis=unit(sub(r.b,r.a)),n=left(axis),L=dist(r.a,r.b);
        const serves=i=>parking.frontages[i].road===r.id && dot(sub(centres[i],r.a),axis)>-.01 && dot(sub(centres[i],r.a),axis)<L+.01;
        const middle=inside.filter(serves);
        const lengths=[1,-1].map(side=>kerbIntervals([cell],r,axis,side*r.width/2)
          .reduce((sum,[a,b])=>sum+Math.max(0,Math.min(L,b)-Math.max(0,a)),0));
        if(Math.max(...lengths)<rule.pitch*1.5)continue;
        const sign=lengths[0]>=lengths[1]?1:-1;
        const outside=centres.map((p,i)=>({p,i,t:dot(sub(p,r.a),axis)})).filter(({p,i})=>serves(i)&&sign*dot(sub(p,r.a),n)<0);
        if(outside.length<2)continue;
        // A true end row borders the surveyed lot, not an interior obstacle.
        if(!outside.some(({p})=>R.nearestEdge(p,f.boundary).length<=rule.depth+.1))continue;
        const count=Math.min(4,Math.max(2,Math.floor(inside.length*.5)),outside.length);
        const facing=middle.length?middle:inside;
        const station=facing.reduce((v,i)=>v+dot(sub(centres[i],r.a),axis),0)/facing.length;
        const ordered=outside.sort((a,b)=>a.t-b.t);
        let row=ordered.slice(0,count),error=Infinity;
        for(let i=0;i+count<=ordered.length;i++){
          const group=ordered.slice(i,i+count),d=Math.abs((group[0].t+group.at(-1).t)/2-station);
          if(d<error){row=group;error=d;}
        }
        const stations=row.flatMap(({i})=>parking.stalls[i].map(p=>dot(sub(p,r.a),axis)));
        const a=add(r.a,axis,Math.min(...stations)+.00005),b=add(r.a,axis,Math.max(...stations)-.00005);
        const depth=-sign*(r.width/2+2*rule.depth);
        const lawn=intersect(f.site,[positive([a,b,add(b,n,depth),add(a,n,depth)])]);
        candidates.push({cell,lawn,road:r.id,open,middle:middle.length,inside:inside.length});
      }
    }
    return candidates.sort((a,b)=>b.open-a.open||b.middle-a.middle)[0];
  }
  function improve(plan,config,assess) {
    const {rule,w}=config;
    if(!plan.net.runs.length||!plan.parking.stalls.length)return plan;
    for(let pass=0;pass<2;pass++){
      const residual=remainder(plan),core=offset(residual,-w/2-.12);
      const pockets=G.groups(core).filter(g=>area(g)>rule.depth*rule.pitch*1.5).sort((a,b)=>area(b)-area(a)).slice(0,3);
      let change=null;
      for(const g of pockets){
        const bb=bounds(g[0]);
        for(const vertical of [bb.y1-bb.y0>bb.x1-bb.x0,bb.y1-bb.y0<=bb.x1-bb.x0]){
          const mid=vertical?(bb.x0+bb.x1)/2:(bb.y0+bb.y1)/2;
          const spans=G.spans(g,mid,vertical).sort((a,b)=>(b[1]-b[0])-(a[1]-a[0]));
          if(!spans.length)continue;
          const [lo,hi]=spans[0];if(hi-lo<rule.pitch*3)continue;
          const a=vertical?[mid,lo]:[lo,mid],b=vertical?[mid,hi]:[hi,mid];
          const proposals=[];
          for(const tip of [a,b])for(const old of plan.net.runs){
            if(old.role==='gate')continue;const q=on(old.a,old.b,tip).p;proposals.push({tip,q,d:dist(q,tip)});
          }
          proposals.sort((u,v)=>u.d-v.d);
          const link=proposals.find(x=>x.d<Math.max(28,3*w)&&plan.f.access.fits(G.strip(x.q,x.tip,w))&&plan.f.access.fits(disk(x.tip,w/2)));
          if(!link)continue;
          const raw=[...plan.raw,{a,b,role:'infill'}];if(link.d>.01)raw.push({a:link.q,b:link.tip,role:'cross'});
          const trial=assess(plan.f,raw,plan.kind,plan.phase,plan.crossShift);
          if(trial.parking.stalls.length>plan.parking.stalls.length&&compare(trial,plan)<0&&(!change||compare(trial,change)<0))change=trial;
        }
      }
      if(!change)break;plan=change;
    }
    return plan;
  }
  function adjustRows(plan,config,assess){
    if(!['linked','loop','spine','grid'].includes(plan.kind))return plan;
    const {w,rule}=config;
    const centres=offset(plan.f.site,-w/2-.018);
    // Move one full row aisle with its end connections, then repack both sides and neighbouring rows.
    // Adjust the actual service line on a sloping boundary rather than translating the clipped parking boxes.
    const rows=plan.raw.filter(r=>r.role==='row').sort((a,b)=>dist(b.a,b.b)-dist(a.a,a.b));
    const levels=[...new Set(rows.map(r=>r.a[1]))].slice(0,area(plan.f.site)>18000?3:8);
    for(const level of levels){
      const base=plan,oldSpans=G.spans(centres,level);
      for(const dy of [-rule.pitch,-.8,.8,rule.pitch]){
        const newSpans=G.spans(centres,level+dy);
        if(!newSpans.length)continue;
        function moveEnd(p){
          if(Math.abs(p[1]-level)>.0001)return p;
          const old=oldSpans.find(([a,b])=>p[0]>=a-.002&&p[0]<=b+.002);
          if(!old)return p;
          const next=newSpans.filter(([a,b])=>b>old[0]&&a<old[1])
            .sort((a,b)=>Math.min(b[1],old[1])-Math.max(b[0],old[0])-(Math.min(a[1],old[1])-Math.max(a[0],old[0])))[0];
          if(!next)return null;
          const x=Math.abs(p[0]-old[0])<.002?next[0]:Math.abs(p[0]-old[1])<.002?next[1]:Math.max(next[0],Math.min(next[1],p[0]));
          return [x,level+dy];
        }
        const raw=base.raw.map(r=>({...r,a:moveEnd(r.a),b:moveEnd(r.b)}));
        if(raw.some((r,i)=>!r.a||!r.b||((r.a!==base.raw[i].a||r.b!==base.raw[i].b)&&
          (dist(r.a,r.b)<.05||!base.f.access.fits(G.strip(r.a,r.b,w))))))continue;
        const p=assess(base.f,raw,base.kind,base.phase,base.crossShift);
        if(compare(p,plan)<0)plan=p;
      }
    }
    return plan;
  }
  function trimRoads(plan,assess){
    // Test a few low-yield service segments, retaining the removal only after the network and bays are rebuilt.
    const counts=new Map();
    for(const f of plan.parking.frontages)counts.set(f.road,(counts.get(f.road)||0)+1);
    const choices=plan.raw.map((r,i)=>({i,yield:(counts.get(i)||0)/Math.max(1,dist(r.a,r.b)),role:r.role}))
      .filter(x=>x.role==='row'||x.role==='infill').sort((a,b)=>a.yield-b.yield).slice(0,3);
    let best=plan;
    for(const {i} of choices){
      const raw=plan.raw.filter((r,j)=>j!==i);if(!raw.length)continue;
      const p=assess(plan.f,raw,plan.kind,plan.phase,plan.crossShift);
      if(compare(p,best)<0)best=p;
    }
    return best;
  }
  function landUse(plan,rule,w){
    const {f,net,parking}=plan,free=remainder(plan);
    if(!parking.stalls.length)return {beds:[],green:[],margin:[],pending:free,trees:[]};
    const reserved=plan.lawn?intersect(free,plan.lawn):[];
    const unserved=G.groups(f.site).filter(g=>area(intersect(g,net.surface))<.002).flat();
    const occupied=union([...net.surface,...parking.blocks]);
    // Close the millimetre-wide drawing gaps at row fronts and between row backs.
    // The resulting faces follow the actual bay, road and survey edges.
    const seam=.03,barriers=offset(offset(occupied,seam),-seam);
    const available=minus(free,union([...reserved,...unserved]));
    const parts=G.groups(minus(available,barriers));
    const band=.06,kerb=offset(net.surface,band),bedsToJoin=reserved.slice(),edging=[];
    const edgeContact=offset(occupied,band);
    for(const part of parts){
      if(!offset(part,-.65).length){
        if(area(intersect(part,edgeContact))>.0001)edging.push(...part);
        continue;
      }
      const doubleAisle=offset(part,-(w/2+rule.depth)).length>0;
      const singleAisle=offset(part,-(w+rule.depth)/2).length>0;
      const mouth=singleAisle && G.groups(intersect(part,kerb)).some(g=>area(g)>=band*w);
      // A face is either wholly available or wholly planted. Offsets measure fit
      // here; their edges must never be drawn as additional planting boundaries.
      if(!doubleAisle&&!mouth)bedsToJoin.push(...part);
    }
    const beds=intersect(free,G.plantingFaces(union(bedsToJoin)));
    const green=union([...beds,...parking.treeIslands]);
    const other=minus(free,beds);
    const margin=intersect(minus(other,unserved),union([...barriers,...edging]));
    const pending=minus(other,margin);
    const trees=parking.treeIslands.map(r=>r.reduce((a,p)=>add(a,p,1/r.length),[0,0]));
    // A dot represents an actual tree position, with room for its planting pit.
    for(const region of G.groups(beds)){
      const inner=offset(region,-1.03);if(!inner.length)continue;
      for(const g of G.groups(inner)){
        const b=bounds(g[0]),vertical=b.y1-b.y0>b.x1-b.x0;
        const low=vertical?b.x0:b.y0,high=vertical?b.x1:b.y1;
        const line=(low+high)/2;
        for(const [lo,hi] of G.spans(g,line,vertical)){const n=Math.max(1,Math.floor((hi-lo)/10));for(let i=0;i<n;i++){const t=lo+(hi-lo)*(i+.5)/n;trees.push(vertical?[line,t]:[t,line]);}}
      }
    }
    return {beds,green,margin,pending,trees};
  }
  function alternatives(zone,opts,config){
    const {rule,w}=config;
    let tested=0;
    function assess(f,raw,kind,phase,shift){
      tested++;
      const plan=build(f,raw,config,kind,phase,shift);
      opts.onCompared?.(tested);
      return plan;
    }
    const refined=new Map();
    function refine(plan){
      if(!refined.has(plan)){
        function repack(net){
          const layouts=[pack(plan.f,net,config,true),pack(plan.f,net,config,false,true)];
          return layouts.map(parking=>({...plan,net,parking,
            travel:routing.measure(net.graph,parking.frontages,config.oneway?'oneway':'twoway')})).sort(compare)[0];
        }
        let result=repack(plan.net);
        if(config.hierarchy){
          let net=sizeServiceAisles(result,config,false);
          // A narrower edge may unlock a second row. Each subsequent pass can
          // only widen an edge or make it bidirectional, so this converges.
          while(net!==result.net){
            result=repack(net);
            net=sizeServiceAisles(result,config,true);
          }
        }
        refined.set(plan,result);
      }
      return refined.get(plan);
    }
    if(opts.manualRoads?.length){
      const raw=opts.manualRoads;
      if(raw.some(r=>![r.a,r.b].every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))))throw Error('车道节点的坐标无效。');
      const f=R.frame(zone,0,config,raw),manualRoads=raw.map(s=>({a:f.local(s.a),b:f.local(s.b),role:Object.hasOwn(R.roles,s.role)&&s.role!=='gate'?s.role:'row'}));
      const ports=Object.values(f.ports).filter(Boolean),shared=ports.length===2&&dist(...ports)<.005;
      if(manualRoads.some(r=>{
        if(dist(r.a,r.b)<.05)return true;
        const p=r.role==='main'&&ports.find(p=>dist(p,r.a)<.005||dist(p,r.b)<.005);
        return p?!R.mainMouth(f,p,dist(r.a,p)<.005?r.b:r.a,shared?Math.max(6,w):w):!f.access.fits(G.strip(r.a,r.b,w));
      }))throw Error('移动后车道的净宽越过边界或碰到障碍，请缩短移动距离。');
      const manual=assess(f,manualRoads,'manual',0,0);
      return [finish(zone,refine(manual),config,tested)];
    }
    const bestByKind=new Map();

    const clearance=config.hierarchy?Math.max(w,config.serviceWidth):w;
    const rowWidth=config.hierarchy?config.serviceWidth:w;
    function axes(f,kind,phase,shift=0){
      return R.pattern(f,clearance,rule.depth,kind,phase,shift,rule.depth,rowWidth);
    }
    function pattern(f,kind,phase,shift=0){
      phase=((phase%1)+1)%1;
      return assess(f,axes(f,kind,phase,shift),kind,phase,shift);
    }
    for(const angle of R.angles(zone,opts.orientation)){
      const f=R.frame(zone,angle,config);
      for(const [kind,phases] of [['ring',[0,.5]],['ladder',[0,.4]]]){
        let atAngle=null;
        for(const phase of new Set(phases.map(t=>Math.round(t*1000)/1000))){
          const plan=pattern(f,kind,phase);
          if(!atAngle||compare(plan,atAngle)<0)atAngle=plan;
        }
        const last=bestByKind.get(kind);
        if(!last||compare(atAngle,last)<0)bestByKind.set(kind,atAngle);
      }
    }
    const finalists=[];
    for(const seed of bestByKind.values()){
      let best=seed;
      for(const offset of [-.14,-.06,.06,.14]){
        const p=pattern(seed.f,seed.kind,seed.phase+offset);
        if(compare(p,best)<0)best=p;
      }
      if(opts.orientation==='auto'){
        const base=best;
        for(const degrees of [-5,-2,2,5]){
          const f=R.frame(zone,base.f.angle+degrees*Math.PI/180,config);
          const p=pattern(f,seed.kind,base.phase);
          if(compare(p,best)<0)best=p;
        }
      }
      best=improve(best,config,assess);
      finalists.push(refine(trimRoads(best,assess)));
    }
    const deck=[];
    const accessible=p=>p && p.gates===2 && p.parking.stalls.length>0 && p.travel.reachable===p.parking.stalls.length;
    const edgeSet=finalists.filter(p=>p.kind==='ring'||p.kind==='ladder');
    const edge=edgeSet.filter(accessible).sort(compare)[0] || edgeSet.sort(compare)[0];
    function put(p,slot,name){
      if(!p)return;
      if(config.hierarchy && accessible(p)){
        const pocket=endPocket(p,rule);
        if(pocket){
          const central=config.endTreatment==='island';
          const lawn=central?offset([pocket.cell],.8):pocket.lawn;
          const local={...config,lawn,endRoad:central?undefined:pocket.road};
          const repack=net=>[pack(p.f,net,local,true),pack(p.f,net,local,false,true)].map(parking=>({...p,net,parking,lawn,
            landscape:{type:config.endTreatment},travel:routing.measure(net.graph,parking.frontages,'twoway')})).sort(compare)[0];
          let treated=repack(p.net),next=sizeServiceAisles(treated,local,false);
          while(next!==treated.net){treated=repack(next);next=sizeServiceAisles(treated,local,true);}
          if(accessible(treated))p=treated;
        }
      }
      deck.push({...finish(zone,p,config,tested),scheme:slot,schemeName:name});
    }
    put(edge,'A','沿边方案');
    const gatePlans=[];
    for(const angle of R.angles(zone,opts.orientation)){
      const f=R.frame(zone,angle,config,true);
      for(const phase of [0,.5]){
        const raw=axes(f,'spine',phase);
        const roads=R.withGateMains(f,raw,w);
        if(!roads)continue;
        const trial=assess(f,roads,'spine',phase,0);
        if(accessible(trial))gatePlans.push(trial);
      }
    }
    // A clipped row grid can leave the gate trunks in different components.
    // In that case connect the two straight approaches through linked rows.
    function fallbackGatePlans(){
      const plans=[];
      if(!zone.entrance||!zone.exit)return plans;
      for(const angle of R.angles(zone,opts.orientation)){
        const f=R.frame(zone,angle,config,true);
        const survey=config.wallWidth?R.frame(zone,angle,{...config,wallWidth:0},true):f;
        for(const kind of ['linked','ladder','ring'])for(const phase of [0,.5]){
          const raw=axes(f,kind,phase);
          const axial=R.withGateMains(f,raw,w,2*w);
          if(axial){
            const p=assess(f,axial,'spine',phase,0);
            if(accessible(p)){plans.push(p);continue;}
          }
          const roads=R.connectGateTrunks(survey,raw,w);
          if(!roads)continue;
          // Validate the actual oblique openings against the wall and obstacles.
          const aligned=config.wallWidth?R.frame(zone,angle,config,roads.map(r=>({...r,a:f.world(r.a),b:f.world(r.b)}))):f;
          const p=assess(aligned,roads,'spine',phase,0);
          if(accessible(p))plans.push(p);
        }
      }
      return plans;
    }
    function closeCircuit(base){
      const inherited=base.net.runs.map(r=>{
        const source=base.raw[r.id];
        const reverse=source&&G.dot(sub(source.b,source.a),sub(r.b,r.a))<0;
        return {a:reverse?r.b:r.a,b:reverse?r.a:r.b,role:r.role,width:source?.width,primary:r.primary};
      });
      const candidates=[];
      for(const link of R.returnCandidates(base,w)){
        const roads=[...inherited,{a:link.a,b:link.b,role:'return'}];
        const net=R.assemble(base.f,roads,w,config.oneway);
        if(config.oneway){
          const lengths=Array(inherited.length).fill(0);
          for(const r of net.runs)if(r.id<lengths.length)lengths[r.id]+=dist(r.a,r.b);
          if(inherited.some((r,i)=>Math.abs(lengths[i]-dist(r.a,r.b))>.005))continue;
        }
        const cycle=R.mainCircuit(net,config.oneway,w,base.f);
        if(cycle)candidates.push({roads,cycle,link});
      }
      // Spend the packing budget on both low-impact links and those serving a
      // long stretch of the main route. Each trial adds exactly one connection.
      const cheapest=candidates.slice(0,12);
      const longest=candidates.sort((a,b)=>b.cycle.shared-a.cycle.shared||a.link.cost-b.link.cost).slice(0,12);
      const loops=[];
      for(const {roads,cycle} of new Set([...cheapest,...longest])){
        const trial=assess(base.f,roads,'return',base.phase,0);
        const packed=refine(trial);
        if(accessible(packed))loops.push({...packed,cycle});
      }
      return loops.sort((a,b)=>compare(a,b)||b.cycle.shared-a.cycle.shared)[0];
    }
    // A connected graph can still force a driver down a very long uninterrupted
    // parking aisle. Use the same crossing spacing as the perimeter layout.
    function linkLongRows(plan){
      const {edges,nodes}=plan.net.graph,spacing=R.crossSpacing;
      const rows=edges.filter(e=>e.role==='row').map(e=>{
        const a=nodes[e.from],b=nodes[e.to];
        return {y:a[1],xs:[Math.min(a[0],b[0]),Math.max(a[0],b[0])]};
      }).sort((a,b)=>a.y-b.y);
      const stations=[];
      for(const {xs:[lo,hi]} of rows){
        const n=Math.ceil((hi-lo)/spacing);
        for(let i=1;i<n;i++)stations.push({x:lo+i*(hi-lo)/n,length:hi-lo});
      }
      const cross=[];
      for(const {x} of stations.sort((a,b)=>b.length-a.length)){
        const hits=[];
        for(const row of rows){
          const i=row.xs.findIndex(v=>v>x);
          if(i<1)continue;
          const lo=row.xs[i-1],hi=row.xs[i];
          hits.push({row,needs:hi-lo>spacing,room:Math.min(x-lo,hi-x)>=w});
        }
        for(let i=1;i<hits.length;i++){
          const a=hits[i-1],b=hits[i];
          if(!a.room||!b.room||(!a.needs&&!b.needs))continue;
          if(b.row.y-a.row.y>rowWidth+2*rule.depth+.05||b.row.y-a.row.y<w)continue;
          const start=[x,a.row.y],end=[x,b.row.y];
          if(!plan.f.access.fits(G.strip(start,end,clearance)))continue;
          cross.push({a:start,b:end,role:'cross'});
          for(const {row} of [a,b])if(!row.xs.includes(x)){row.xs.push(x);row.xs.sort((u,v)=>u-v);}
        }
      }
      if(!cross.length)return plan;
      const linked=assess(plan.f,[...plan.raw,...cross],plan.kind,plan.phase,plan.crossShift);
      return accessible(linked)?linked:plan;
    }
    let straight=null,loop=null;
    function tryBases(plans){
      for(const trial of plans.sort(compare)){
        const base=refine(linkLongRows(improve(trial,config,assess)));
        if(!accessible(base))continue;
        if(!straight)straight=base;
        const candidate=closeCircuit(base);
        if(candidate){straight=base;loop=candidate;break;}
      }
    }
    // A through road can serve both gates while its side streets miss an entire
    // wing. Compare grids with linked row ends whenever that wing can still
    // accommodate a full double-loaded aisle.
    const seed=gatePlans.sort(compare)[0];
    const searchLinked=!seed||offset(remainder(seed),-(rowWidth/2+rule.depth)).some(r=>G.siteArea(r)>rule.pitch**2);
    if(searchLinked)gatePlans.push(...fallbackGatePlans());
    tryBases(gatePlans);
    if(!loop&&!searchLinked)tryBases(fallbackGatePlans());
    put(straight,'B','出入口主通道');
    put(loop,'C','环形主通道');
    for(const p of deck)p.stats.candidates=tested;
    return deck;
  }
  function doublePlanting(beds,oldTrees,world){
    const placed=[],candidates=[],target=2*oldTrees.length;
    if(!target)return [];
    for(const bed of beds){
      const inner=offset(bed,-.65);
      if(!inner.length)continue;
      const room=prepare(bed),pit=prepare(inner),anchors=oldTrees.filter(room.has);
      const edges=new G.Index(3);
      for(const ring of bed)ring.forEach((a,i)=>{
        const b=ring[(i+1)%ring.length];edges.put(bounds([a,b]),[a,b]);
      });
      const box=bounds(bed[0]),spots=[];
      function offer(p){
        if(!pit.has(p))return;
        const radius=ParkingTrees.radius*ParkingTrees.placement(world(p)).scale;
        const reach=Math.max(3,radius);
        let clearance=reach;
        for(const [a,b] of edges.near({x0:p[0]-reach,y0:p[1]-reach,x1:p[0]+reach,y1:p[1]+reach})){
          clearance=Math.min(clearance,dist(p,on(a,b,p).p));
          if(clearance<radius)return;
        }
        spots.push({p,radius,clearance,nearest:Infinity});
      }
      anchors.forEach(offer);
      const grid=.45;
      for(let y=box.y0+.65;y<box.y1-.64;y+=grid)
        for(const [lo,hi] of G.spans(inner,y,false)){
          const count=Math.max(1,Math.ceil((hi-lo)/grid));
          for(let i=0;i<count;i++)offer([lo+(i+.5)*(hi-lo)/count,y]);
        }
      if(spots.length)candidates.push({spots,wanted:anchors.length*2});
    }
    function place(group){
      let best=null,score=-Infinity;
      for(const s of group.spots){
        if(s.nearest<s.radius+.08)continue;
        const value=Math.min(s.nearest,12)+Math.min(s.clearance,3)*.4-s.radius;
        if(value>score){score=value;best=s;}
      }
      if(!best)return false;
      placed.push(best.p);
      for(const g of candidates)for(const s of g.spots)
        s.nearest=Math.min(s.nearest,dist(s.p,best.p)-best.radius);
      return true;
    }
    for(const g of candidates)for(let i=0;i<g.wanted&&placed.length<target;i++)if(!place(g))break;
    // On tiny islands two crowns may not fit. Use other plantable ground
    // to reach the same overall density without overlapping the bays.
    let added=true;
    while(placed.length<target&&added){
      added=false;
      for(const g of candidates)if(placed.length<target&&place(g))added=true;
    }
    return placed;
  }
  function finish(zone,best,config,tested){
    const {rule,w}=config;
    const {f,net,parking}=best,land=landUse(best,rule,w);
    // Restore contacts to the exact survey line after integer clipping.
    const boundaryIndex=new G.Index(18),snap=.0000035;
    for(const ring of [zone.boundary,...zone.obstacles])ring.forEach((a,i)=>{
      const b=ring[(i+1)%ring.length],bb=bounds([f.local(a),f.local(b)]);
      boundaryIndex.put({x0:bb.x0-snap,x1:bb.x1+snap,y0:bb.y0-snap,y1:bb.y1+snap},[a,b]);
    });
    function W(p){
      const q=f.world(p);let best=q,min=snap;
      for(const [a,b] of boundaryIndex.near({x0:p[0]-snap,x1:p[0]+snap,y0:p[1]-snap,y1:p[1]+snap})){
        const hit=on(a,b,q),d=dist(q,hit.p);if(d<min){best=hit.p;min=d;}
      }
      return best;
    }
    const rings=arr=>arr.map(r=>r.map(W)),usable=area(f.site);
    const allArea=G.siteArea(zone.boundary);
    const plantedObstacles=zone.obstacles.filter((_,i)=>zone.obstacleGround?.[i]==='green');
    const bayFootprint=union(parking.stalls);
    const freeGround=minus([f.boundary],union([...bayFootprint,...net.surface,...f.insideWall]));
    const residualBeds=G.plantingFaces(intersect(freeGround,land.green));
    const prescribed=plantedObstacles.map(r=>positive(r.map(f.local)));
    const grossGreen=prescribed.length?union([...residualBeds,...intersect(freeGround,union(prescribed))]):residualBeds;
    const roadEdges=config.curbWidth?offset(net.surface,config.curbWidth):net.surface;
    const rawCurb=config.curbWidth?intersect(grossGreen,roadEdges):[];
    const formerGreen=minus(grossGreen,rawCurb);
    const rounded=G.roundGrass(G.groups(formerGreen),net.arcs,config.curbWidth,
      {stalls:parking.stalls,roadEdges,fixedEdges:[f.boundary,...zone.obstacles.map(r=>r.map(f.local))]});
    const beds=rounded.beds;
    const greenBeds=beds.map((g,i)=>({id:i+1,area:rounded.areas[i],rings:rings(g),
      curves:rounded.outlines[i].map(r=>r.map(([x,y,b])=>[...W([x,y]),b]))}));
    const planting=beds.flat();
    const specifiedPaving=zone.obstacles.filter((_,i)=>zone.obstacleGround?.[i]==='paved');
    const pavedObstacles=specifiedPaving.map(r=>positive(r.map(f.local)));
    const rawHardscape=minus(intersect(freeGround,union([...land.margin,...pavedObstacles])),grossGreen);
    const {road,curb,hardscape,moved}=G.joinGrassKerbs(net.surface,rawCurb,rawHardscape,formerGreen,
      planting,rounded,config.curbWidth,f.site);
    const margin=moved.length?minus(land.margin,moved):land.margin;
    const pavedGround=union([...road,...hardscape,...curb]);
    const pending=minus(freeGround,union([...planting,...hardscape,...curb,...moved]));
    const exactGreen=rounded.areas.reduce((sum,a)=>sum+a,0);
    const arcDifference=exactGreen-area(planting),pendingArea=area(pending);
    const treeRoom=prepare(config.curbWidth?offset(planting,-.65):planting);
    const oldTrees=land.trees.filter(treeRoom.has);
    const trees=doublePlanting(beds,oldTrees,W);
    const surfaceAreas={total:allArea,paved:area(pavedGround)-arcDifference,green:exactGreen,stalls:area(bayFootprint)};
    if(pendingArea>0)surfaceAreas.pending=pendingArea;
    if(config.wallWidth)surfaceAreas.wall=area(f.insideWall);
    const graph={nodes:net.graph.nodes.map(W),edges:net.graph.edges.map(e=>({...e})),ports:net.graph.ports,connected:net.graph.connected};
    const openings={};for(const k of ['entrance','exit']){
      const g=net.portInfo[k];openings[k]={connected:net.graph.connected[k],message:g.message,points:g.opening?.map(W)||[]};
    }
    const runs=net.runs.map(r=>({...r,a:W(r.a),b:W(r.b)}));
    const stats={siteArea:allArea,obstacleArea:Math.max(0,allArea-area(f.insideWall)-usable),curbArea:area(curb)-(config.curbWidth?arcDifference:0),wallArea:area(f.wall),roadArea:area(road)-(config.curbWidth?0:arcDifference),stallArea:surfaceAreas.stalls,greenArea:surfaceAreas.green,
      pavedArea:surfaceAreas.paved,marginArea:area(margin),pendingArea,surfaceAreas,
      balanceError:Math.abs(allArea-surfaceAreas.stalls-surfaceAreas.paved-exactGreen-pendingArea-area(f.insideWall)),
      ...best.travel,candidates:tested,rows:parking.rows.filter(r=>r.capacity).length,servedAisles:new Set(parking.rows.filter(r=>r.capacity).map(r=>r.road)).size,
      links:runs.filter(r=>r.role==='cross').length,deadEnds:net.dead,treeCount:trees.length,treeTarget:2*oldTrees.length,spaces:parking.stalls.length};
    const steps={return:'出入口主通道与一条回车联络道',ladder:'双端联通车排与沿边通道',ring:'沿边环道与分排通道',grid:'并列通道与横向联络道',spine:'入口主通道与分排支道',loop:'车排尽端内收联络',linked:'车排端部联络',manual:'手调路网'};
    const ok=stats.spaces>0&&stats.reachable===stats.spaces;
    const checks={geometry:stats.spaces?'车位在区内，车位口接通车道':'当前轮廓或路网放不下可服务车位',
      entrance:net.graph.connected.entrance?'已接入可达路网':(openings.entrance.message==='接入'?'与主路网断开':openings.entrance.message),
      exit:net.graph.connected.exit?'已接入可达路网':(openings.exit.message==='接入'?'与主路网断开':openings.exit.message),
      turning:`内侧路缘圆角 R${R.kerbRadius} m，已生成内缘 ${net.arcs.filter(a=>a.inner).length} 处，受限保留原角 ${net.unrounded} 处；车辆扫掠及外部接入待复核`};
    const patches=[];
    function record(kind,groups){
      for(const g of groups)patches.push({kind,area:Math.abs(area(g)),rings:rings(g)});
    }
    record('bed',G.groups(intersect(land.beds,planting)));record('tree',G.groups(intersect(parking.treeIslands,planting)));
    record('pave',G.groups(margin));record('pending',G.groups(pending));
    patches.sort((a,b)=>b.area-a.area);
    let signature=2166136261;
    for(const r of net.runs)for(const n of [...r.a,...r.b]){
      signature=Math.imul(signature^Math.round(n*1000),16777619);
    }
    const variantId=[best.kind,Math.round(f.angle*10000),Math.round(best.phase*1000),Math.round(best.crossShift*100),(signature>>>0).toString(36)].join('/');
    const landscape=best.landscape?{...best.landscape,rings:rings(intersect(planting,best.lawn)),area:area(intersect(planting,best.lawn))}:null;
    return {method:'full-site-network/v3',variantId,family:best.kind,patches,greenBeds,grassCleanup:rounded.summary,landscape,stallModes:parking.stallModes,stallSizes:parking.stallSizes,strategy:steps[best.kind],stats,checks,exportable:ok,frontages:parking.frontages.map(v=>({road:v.road,p:W(v.p)})),comparisonAngle:f.angle*180/Math.PI,
      stalls:rings(parking.stalls),aisles:rings(G.pieces(road)),roadSurface:rings(road),green:rings(planting),paving:rings(margin),pavedGround:rings(pavedGround),hardscape:rings(hardscape),curb:rings(curb),wall:rings(f.wall),pending:rings(pending),
      kerbRadius:R.kerbRadius,kerbArcs:net.arcs.map(a=>({...a,points:a.points.map(W)})),unroundedKerbs:net.unrounded,kerbLimits:net.limits,
      trees:trees.map(W),treeIslands:rings(intersect(parking.treeIslands,planting)),openings,graph,runs,
      rows:parking.rows.map(r=>({...r,a:W(r.a),b:W(r.b)}))};
  }
  return {alternatives,stallLimitError};
}
globalThis.createParkingPlanner=createParkingPlanner;
