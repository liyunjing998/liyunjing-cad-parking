/* All polygon operations use metres in a local coordinate frame. */
function createParkingGeometry(C) {
  'use strict';
  const scale = 1000000, tolerance = 0.00015;
  const add = (a,b,k=1) => [a[0]+k*b[0],a[1]+k*b[1]];
  const sub = (a,b) => [a[0]-b[0],a[1]-b[1]];
  const dot = (a,b) => a[0]*b[0]+a[1]*b[1];
  const cross = (a,b) => a[0]*b[1]-a[1]*b[0];
  const length = a => Math.hypot(...a);
  const dist = (a,b) => length(sub(a,b));
  const unit = a => {const d=length(a);return d?[a[0]/d,a[1]/d]:[0,0];};
  const left = a => [-a[1],a[0]];
  const lerp = (a,b,t) => add(a,sub(b,a),t);
  const on = (a,b,p) => {const d=sub(b,a);const t=Math.max(0,Math.min(1,dot(sub(p,a),d)/(dot(d,d)||1)));return {t,p:lerp(a,b,t)};};
  const signed = ring => {const o=ring[0];let s=0;for(let i=1;i+1<ring.length;i++)s+=cross(sub(ring[i],o),sub(ring[i+1],o));return s/2;};
  const siteArea = boundary=>Math.abs(signed(boundary));
  const positive = r => signed(r)>0?r:r.slice().reverse();
  const area = rings => rings.reduce((s,r)=>s+signed(r),0);
  function bounds(points) {
    let x0=Infinity,x1=-Infinity,y0=Infinity,y1=-Infinity;
    for(const [x,y] of points){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
    return {x0,x1,y0,y1};
  }
  const int = r=>r.map(([x,y])=>({X:Math.round(scale*x),Y:Math.round(scale*y)}));
  const real = r=>r.map(({X,Y})=>[X/scale,Y/scale]);
  function operation(kind,subject,clip=[],tree=false) {
    const c=new C.Clipper(),out=tree?new C.PolyTree():[];
    c.StrictlySimple=true;
    if(subject.length)c.AddPaths(subject.map(int),C.PolyType.ptSubject,true);
    if(clip.length)c.AddPaths(clip.map(int),C.PolyType.ptClip,true);
    c.Execute(kind,out,C.PolyFillType.pftNonZero,C.PolyFillType.pftNonZero);
    return tree?C.JS.PolyTreeToExPolygons(out).map(g=>[real(g.outer),...g.holes.map(real)]):out.map(real).filter(r=>r.length>2 && Math.abs(signed(r))>1e-7);
  }
  const union = rings=>operation(C.ClipType.ctUnion,rings);
  const intersect = (a,b)=>a.length&&b.length?operation(C.ClipType.ctIntersection,a,b):[];
  const minus = (a,b)=>b.length?operation(C.ClipType.ctDifference,a,b):a.slice();
  const groups = r=>operation(C.ClipType.ctUnion,r,[],true);
  function offset(rings,d) {
    if(!rings.length)return [];
    const c=new C.ClipperOffset(3,scale*.03),out=[];
    c.AddPaths(rings.map(int),C.JoinType.jtMiter,C.EndType.etClosedPolygon);
    c.Execute(out,d*scale);
    return out.map(real);
  }
  // A few millimetres of construction clearance between adjacent markings can
  // connect whole planting beds. Preserve the surveyed tips of each intact
  // face and separate only those faces joined by a narrow construction gap.
  // Flat-ended strips on straights and annular sectors on circular turns.
  // Check polygon edges analytically, including tangency and a green island
  // contained entirely inside the envelope. Distances are in model metres.
  function laneProbe(rings,{outside=false}={}) {
    const edges=new Index(12),region=prepare(rings),half=2.5,eps=.001;
    for(const ring of rings)ring.forEach((a,i)=>{
      const b=ring[(i+1)%ring.length];edges.put(bounds([a,b]),[a,b]);
    });
    return function check(a,b,bulge=0) {
      const chord=dist(a,b);
      if(chord<1e-7)return {status:'clear'};
      const dir=unit(sub(b,a)),normal=left(dir),mid=lerp(a,b,.5);
      let sample=mid,extent=bounds([a,b]),contains,intersections;
      if(Math.abs(bulge)<1e-9){
        contains=(p,h)=>{const q=sub(p,a),x=dot(q,dir);const pad=h-half;return x>=-pad&&x<=chord+pad&&Math.abs(dot(q,normal))<=h;};
        intersections=(u,v,h)=>{const r=strip(add(a,dir,half-h),add(b,dir,h-half),h*2);
          for(let i=0;i<4;i++){const hit=cuts(u,v,r[i],r[(i+1)%4]);if(hit)return hit.p;}
        };
      }else{
        const center=add(mid,normal,chord*(1-bulge*bulge)/(4*bulge));
        const radius=dist(center,a),sweep=4*Math.atan(bulge),angle=Math.atan2(a[1]-center[1],a[0]-center[0]);
        const at=(t,r)=>add(center,[Math.cos(angle+t*sweep),Math.sin(angle+t*sweep)],r);
        const onSweep=(p,h=half)=>{const q=sub(p,center),v=Math.sign(sweep)*(Math.atan2(q[1],q[0])-angle);
          const t=(v+2*Math.PI)%(2*Math.PI);const pad=(h-half)/radius;
          if(pad<0)return t>=-pad&&t<=Math.abs(sweep)+pad;
          return t<=Math.abs(sweep)+pad+1e-9||t>=2*Math.PI-pad-1e-9;};
        sample=at(.5,radius);
        extent=bounds([a,b,...[[1,0],[0,1],[-1,0],[0,-1]].map(v=>add(center,v,radius)).filter(p=>onSweep(p))]);
        contains=(p,h)=>Math.abs(dist(p,center)-radius)<=h&&onSweep(p,h);
        intersections=(u,v,h)=>{
          const lo=Math.max(0,radius-h),hi=radius+h;
          const pad=(h-half)/(radius*Math.abs(sweep));
          for(const t of [-pad,1+pad]){const hit=cuts(u,v,at(t,lo),at(t,hi));if(hit)return hit.p;}
          const d=sub(v,u),q=sub(u,center),n=dot(d,d);
          if(n<1e-18)return;
          for(const r of [lo,hi]){
            const z=dot(q,d),delta=z*z-n*(dot(q,q)-r*r);
            if(delta<0)continue;
            for(const t of [(-z-Math.sqrt(delta))/n,(-z+Math.sqrt(delta))/n]){
              if(t<0||t>1)continue;
              const hit=add(u,d,t);if(onSweep(hit,h))return hit;
            }
          }
        };
      }
      const pad=half+eps,near=edges.near({x0:extent.x0-pad,x1:extent.x1+pad,y0:extent.y0-pad,y1:extent.y1+pad});
      if(region.has(sample)!==outside)return {status:'overlap',point:sample};
      for(const [h,status] of [[half-eps,'overlap'],[pad,'touch']]){
        for(const [u,v] of near){
          const point=contains(u,h)?u:contains(v,h)?v:intersections(u,v,h);
          if(point)return {status,point};
        }
      }
      return {status:'clear'};
    };
  }

  // The angle is on the planted side of an outward corner. Snap only the
  // roundoff at a bin boundary (the clipping grid is one micrometre).
  function grassRadius(angle) {
    const degrees=Math.round(angle*1e4)/1e4;
    if(degrees<30)return 0;
    if(degrees<50)return 2;
    if(degrees<70)return 3;
    if(degrees<90)return 4;
    return 5;
  }
  function curveArea(vertices){
    let result=signed(vertices);
    vertices.forEach((p,i)=>{
      const b=p[2];if(!b)return;
      const sweep=4*Math.atan(b),radius=dist(p,vertices[(i+1)%vertices.length])*(1+b*b)/(4*Math.abs(b));
      result+=radius*radius*(sweep-Math.sin(sweep))/2;
    });
    return result;
  }
  // Computations that need polygons use chords with a sagitta below 0.1 mm.
  // CAD outlines, hatches and surface schedules keep the actual circular arcs.
  function sampleGrassRing(vertices){
    const points=[];
    vertices.forEach(([x,y,b],i)=>{
      const p=[x,y],next=vertices[(i+1)%vertices.length];
      points.push(p);
      if(!b)return;
      const d=sub(next,p),center=add(lerp(p,next,.5),left(d),(1-b*b)/(4*b));
      const radius=dist(center,p),sweep=4*Math.atan(b),start=Math.atan2(y-center[1],x-center[0]);
      const step=2*Math.acos(Math.max(-1,1-.0001/radius)),n=Math.max(2,Math.ceil(Math.abs(sweep)/step));
      for(let j=1;j<n;j++){
        const angle=start+sweep*j/n;
        points.push([center[0]+radius*Math.cos(angle),center[1]+radius*Math.sin(angle)]);
      }
    });
    return points;
  }
  // Find overlapping straight segments, allowing for the 4 mm packing seam.
  // Footprint rings keep their material on the left. A neighbouring footprint
  // therefore traverses a shared side in the opposite direction to the lawn.
  const sideSeam=.006;
  function sharedSideSpans(rings){
    const sides=new Index(8);
    for(const ring of rings)ring.forEach((a,i)=>{
      const b=ring[(i+1)%ring.length];
      if(dist(a,b)>tolerance)sides.put(bounds([a,b]),{a,b,axis:unit(sub(b,a))});
    });
    return (a,b)=>{
      const axis=unit(sub(b,a)),len=dist(a,b),box=bounds([a,b]);
      const spans=[];
      for(const side of sides.near({x0:box.x0-sideSeam,x1:box.x1+sideSeam,y0:box.y0-sideSeam,y1:box.y1+sideSeam})){
        if(dot(axis,side.axis)>=0||Math.abs(cross(axis,side.axis))>.001)continue;
        const u=sub(side.a,a),v=sub(side.b,a);
        if(Math.max(Math.abs(cross(axis,u)),Math.abs(cross(axis,v)))>sideSeam)continue;
        const s=dot(u,axis),t=dot(v,axis);
        const lo=Math.max(0,Math.min(s,t)),hi=Math.min(len,Math.max(s,t));
        if(hi-lo>tolerance)spans.push([lo,hi]);
      }
      const merged=[];
      for(const span of spans.sort((x,y)=>x[0]-y[0])){
        const last=merged.at(-1);
        if(last&&span[0]<=last[1]+sideSeam)last[1]=Math.max(last[1],span[1]);
        else merged.push(span);
      }
      return merged;
    };
  }
  function roundGrass(groups,kerbs=[],curbWidth=0,{stalls=[],roadEdges=[],fixedEdges=[]}={}){
    const beds=[],outlines=[],areas=[],roadCorners=[],pi=Math.PI;
    const bayContact=sharedSideSpans(stalls.map(positive)),roadContact=sharedSideSpans(roadEdges);
    const roadBox=bounds(roadEdges.flat());
    const fixedContact=sharedSideSpans(fixedEdges.flatMap(r=>[r,r.slice().reverse()]));
    // Clipping may introduce collinear vertices where a parking row starts.
    // Classify the whole straight side so a short road-facing stub cannot
    // make a corner round when the rest of the same side touches a bay.
    function lawnSides(ring){
      const n=ring.length,labels=new Array(n);
      const dirs=ring.map((p,i)=>unit(sub(ring[(i+1)%n],p)));
      const straight=(a,b)=>dot(a,b)>0&&Math.abs(cross(a,b))<.00001745;
      const first=dirs.findIndex((dir,i)=>!straight(dir,dirs[(i+n-1)%n]));
      if(first<0)return labels.fill('other');
      for(let start=0;start<n;){
        const i=(first+start)%n;
        let end=start+1;
        while(end<n&&straight(dirs[i],dirs[(first+end)%n]))end++;
        const a=ring[i],b=ring[(first+end)%n],length=dist(a,b);
        let label='other';
        if(bayContact(a,b).length)label='stall';
        else if(!fixedContact(a,b).length){
          const spans=roadContact(a,b);
          if(spans.length===1&&spans[0][0]<=sideSeam&&spans[0][1]>=length-sideSeam)label='road';
        }
        for(let k=start;k<end;k++)labels[(first+k)%n]=label;
        start=end;
      }
      return labels;
    }
    const summary={rule:'graded-v4',corners:0,byStalls:0,otherEdges:0,clipped:0,reduced:0,skipped:0,smallArcs:0,radii:{1:0,2:0,3:0,4:0,5:0},area:0};
    // Polygon booleans split existing road fillets into short chords. Their
    // sampled vertices (also along an offset curb) are already smooth.
    const circular=new Index(12),pad=curbWidth+.006;
    for(const arc of kerbs){
      const a=arc.points[0],b=arc.points.at(-1),k=arc.bulge;
      if(!k)continue;
      const center=add(lerp(a,b,.5),left(sub(b,a)),(1-k*k)/(4*k)),bb=bounds(arc.points);
      circular.put({x0:bb.x0-pad,y0:bb.y0-pad,x1:bb.x1+pad,y1:bb.y1+pad},{center,radius:dist(center,a)});
    }
    function onCurve(p,u,v){
      for(const {center,radius} of circular.near({x0:p[0],y0:p[1],x1:p[0],y1:p[1]})){
        const n=unit(sub(p,center));
        if(Math.abs(dist(p,center)-radius)<=pad&&Math.max(Math.abs(dot(u,n)),Math.abs(dot(v,n)))<.06)return true;
      }
      return false;
    }
    // Bay joints can leave 4 mm steps and duplicate clipping vertices. Remove
    // only shallow convex ears inside the same face before measuring tangents.
    function removeSlivers(bed){
      let ring=bed[0].slice(),changed=true;
      while(changed&&ring.length>3){
        changed=false;
        const region=prepare([ring,...bed.slice(1)]),retained=[],n=ring.length,sides=lawnSides(ring);
        for(let i=0;i<n;i++){
          const p=ring[i],a=ring[(i+n-1)%n],b=ring[(i+1)%n];
          const u=unit(sub(p,a)),v=unit(sub(b,p));
          const small=dist(p,on(a,b,p).p)<.01;
          // Removing an ear changes both full sides, beyond just the tip.
          if(small&&cross(u,v)>=0&&!onCurve(p,u,v)&&
              sides[(i+n-1)%n]==='road'&&sides[i]==='road'&&region.fits([a,p,b])&&
              retained.length+n-i>3 && (!changed||retained.at(-1)===a) && (i!==n-1||retained[0]===ring[0])){
            changed=true;
          }else retained.push(p);
        }
        ring=retained;
      }
      return ring;
    }
    // Closing the 3 cm gaps between road/bay footprints can give an acute
    // road island a short flat nose. Measure the angle between its two flanks.
    // Restore the two original vertices if the proposed larger cut cannot fit.
    function recoverTips(original){
      const n=original.length,restore=new Map(),omit=new Set(),replacement=new Map();
      if(n<4)return {ring:original,restore};
      for(let i=0;i<n;i++){
        const j=(i+1)%n,a=original[i],b=original[j],cap=dist(a,b);
        if(omit.has(i)||replacement.has(j)||cap>.085||cap<tolerance)continue;
        const u=unit(sub(a,original[(i+n-1)%n])),v=unit(sub(original[(j+1)%n],b));
        const turn=Math.atan2(cross(u,v),dot(u,v)),ab=sub(b,a);
        if(turn<=5*pi/6||cross(u,ab)<=0||cross(ab,v)<=0)continue;
        const sine=cross(u,v);
        if(sine<=1e-10)continue;
        const tip=add(a,u,cross(ab,v)/sine);
        // Almost parallel flanks can meet far outside this parking lot.
        // A clipped road kerb can only have a tip within the road footprint.
        if(tip[0]<roadBox.x0-sideSeam||tip[0]>roadBox.x1+sideSeam||
            tip[1]<roadBox.y0-sideSeam||tip[1]>roadBox.y1+sideSeam||
            dot(sub(tip,a),u)<=0||dot(sub(b,tip),v)<=0)continue;
        if(bayContact(a,b).length||fixedContact(a,b).length)continue;
        const approach=roadContact(a,tip),departure=roadContact(tip,b);
        const covers=(spans,length)=>spans.length===1&&spans[0][0]<=sideSeam&&spans[0][1]>=length-sideSeam;
        if(!covers(approach,dist(a,tip))||!covers(departure,dist(tip,b)))continue;
        replacement.set(i,tip);omit.add(j);restore.set(tip,[a,b]);
      }
      const ring=original.flatMap((p,i)=>omit.has(i)?[]:[replacement.get(i)||p]);
      return ring.length>=3?{ring,restore}:{ring:original,restore:new Map()};
    }
    for(const bed of groups){
      const {ring,restore}=recoverTips(removeSlivers(bed)),count=ring.length;
      const mask=prepare([ring,...bed.slice(1)]),taken=new Index(9);
      const sides=lawnSides(ring);
      const lengths=ring.map((p,i)=>dist(p,ring[(i+1)%count]));
      const remaining=lengths.slice(),corners=[],turns=[];
      for(let i=0;i<count;i++){
        const prev=(i+count-1)%count,p=ring[i],u=unit(sub(p,ring[prev])),v=unit(sub(ring[(i+1)%count],p));
        const turn=Math.atan2(cross(u,v),dot(u,v));
        // Reflex notches and interior holes are exclusions. Rounding them with
        // a tangent arc would plant into the aisle, stall or unknown ground.
        if(turn<.001*pi/180||onCurve(p,u,v))continue;
        if(sides[prev]==='stall'||sides[i]==='stall'){summary.byStalls++;continue;}
        if(sides[prev]!=='road'||sides[i]!=='road'){summary.otherEdges++;continue;}
        const angle=180-turn*180/pi;
        corners.push({i,prev,p,u,v,turn,r:grassRadius(angle)});
      }
      // Give sharp tips first choice of tangents; both ends share one edge
      // budget. A small reservation keeps the next corner from being stranded.
      const active=new Set(corners.map(c=>c.i));
      corners.sort((a,b)=>b.turn-a.turn||a.p[0]-b.p[0]||a.p[1]-b.p[1]);
      for(const {i,prev,p,u,v,turn,r} of corners){
        active.delete(i);
        const next=(i+1)%count,available=(edge,neighbor)=>remaining[edge]-
          (active.has(neighbor)?Math.min(.001,lengths[edge]*.02):0);
        const limit=Math.min(available(prev,prev),available(i,next)),tangent=Math.tan(turn/2);
        const nose=restore.get(p),oldStep=nose?Math.max(...nose.map(q=>dist(q,p))):0;
        function accept(step,radius){
          if(step<.00001||step>limit+1e-8)return false;
          if(nose&&step<=oldStep+tolerance)return false;
          const a=add(p,u,-step),b=add(p,v,step),cut=[a,p,b],box=bounds(cut);
          if(!mask.fits(cut)||Array.from(taken.near(box)).some(t=>overlap(t,cut)))return false;
          taken.put(box,cut);remaining[prev]-=step;remaining[i]-=step;
          turns[i]=[[...a,radius?Math.tan(turn/4):0],[...b,0]];
          // Include the old road-side curb vertex, even at acute mitres.
          // Only land already assigned to lawn, paving or curb can transfer.
          const pad=curbWidth+sideSeam*2,nu=left(u),nv=left(v);
          const reach=Math.min(pad*tangent,Math.hypot(roadBox.x1-roadBox.x0,roadBox.y1-roadBox.y0)+pad);
          const outside=add(add(p,nu,-pad),u,reach);
          roadCorners.push(positive([a,add(a,nu,-pad),outside,add(b,nv,-pad),b]));
          summary.corners++;
          if(!radius)summary.clipped++;
          else if(radius<1)summary.smallArcs++;
          else summary.radii[radius]++;
          if(radius<r)summary.reduced++;
          return true;
        }
        let done=false;
        for(let radius=r;radius>=1&&!done;radius--)done=accept(radius*tangent,radius);
        if(!done){
          // A narrow island still gets a tangent arc. Only the <30° group
          // receives a straight bevel; a constrained arc keeps its actual radius.
          // At 10 degrees a 1 m setback leaves a face only 17 cm wide.
          // Size a bevel by its visible face (1 m), subject to real free room.
          const share=r ? 0.49 : 1;
          let setback=Math.min(r?tangent*.999:.5/Math.cos(turn/2),limit,
            share*lengths[prev],share*lengths[i]);
          while(!done&&setback>=.00001){
            done=accept(setback,r?setback/tangent:0);
            setback/=2;
          }
        }
        if(!done)summary.skipped++;
      }
      const outer=[];
      for(const [i,p] of ring.entries())for(const v of turns[i]||(restore.get(p)||[p]).map(q=>[...q,0])){
        if(outer.length&&dist(outer.at(-1),v)<1e-8)outer.pop();
        outer.push(v);
      }
      if(outer.length>1&&dist(outer[0],outer.at(-1))<1e-8)outer.pop();
      const curves=[outer,...bed.slice(1).map(r=>r.map(p=>[...p,0]))];
      const rings=[sampleGrassRing(outer),...bed.slice(1)],exact=curves.reduce((n,r)=>n+curveArea(r),0);
      beds.push(rings);outlines.push(curves);areas.push(exact);
      summary.area+=Math.max(0,area(bed)-exact);
    }
    return {beds,outlines,areas,summary,roadCorners};
  }
  // Both sides of an accepted corner border the same road network. Move its
  // actual kerb and its material footprint together with the lawn boundary.
  function joinGrassKerbs(road,curb,hardscape,formerGreen,planting,cut,curbWidth,site){
    if(!cut.roadCorners.length)return {road,curb,hardscape,moved:[]};
    const windows=intersect(union(cut.roadCorners),site);
    const changeable=union([...formerGreen,...curb,...hardscape]);
    const moved=minus(intersect(windows,changeable),planting);
    if(!moved.length)return {road,curb,hardscape,moved};
    const band=curbWidth?intersect(moved,offset(planting,curbWidth)):[];
    const extra=minus(moved,band);
    // Road and lawn were clipped independently to the micrometre grid. Join
    // only contacting faces so a sub-grid slit cannot draw both old tangents.
    const weld=extra.length?minus(intersect(windows,intersect(offset(road,.00003),offset(extra,.00003))),[...planting,...band]):[];
    return {road:extra.length?union([...road,...extra,...weld]):road,hardscape:minus(hardscape,moved),
      curb:band.length?union([...minus(curb,moved),...band]):minus(curb,moved),moved};
  }
  function plantingFaces(rings){
    return union(groups(rings).flatMap(face=>{
      const cores=groups(offset(face,-.006));
      if(cores.length===1)return face;
      return cores.flatMap(core=>intersect(face,offset(core,.006)));
    }));
  }
  function inside(p,ring) {
    let flag=false;
    for(let i=0,j=ring.length-1;i<ring.length;j=i++){
      const a=ring[j],b=ring[i];
      if((a[1]>p[1])!==(b[1]>p[1]) && p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])flag=!flag;
    }
    return flag;
  }
  function cuts(a,b,c,d) {
    const u=sub(b,a),v=sub(d,c),det=cross(u,v),q=sub(c,a);
    if(Math.abs(det)<1e-10)return null;
    const t=cross(q,v)/det,s=cross(q,u)/det;
    return t>=-1e-7&&t<=1+1e-7&&s>=-1e-7&&s<=1+1e-7?{p:lerp(a,b,Math.max(0,Math.min(1,t))),t,s}:null;
  }
  class Index {
    constructor(cell=9){this.cell=cell;this.map=new Map();}
    cells(b,fn){const s=this.cell;for(let x=Math.floor(b.x0/s);x<=Math.floor(b.x1/s);x++)for(let y=Math.floor(b.y0/s);y<=Math.floor(b.y1/s);y++)fn(x+','+y);}
    put(b,item){this.cells(b,k=>{let a=this.map.get(k);if(!a){a=[];this.map.set(k,a);}a.push(item);});}
    near(b){const out=new Set();this.cells(b,k=>{for(const v of this.map.get(k)||[])out.add(v);});return out;}
  }
  function overlap(a,b) { // Strict separating-axis test for convex footprints; touching kerbs are allowed.
    for(const r of [a,b])for(let i=0;i<r.length;i++){
      const n=left(unit(sub(r[(i+1)%r.length],r[i])));
      const aa=a.map(p=>dot(p,n)),bb=b.map(p=>dot(p,n));
      if(Math.max(...aa)<=Math.min(...bb)+tolerance||Math.max(...bb)<=Math.min(...aa)+tolerance)return false;
    }
    return true;
  }
  function prepare(rings) {
    const index=new Index(),byHeight=new Map(),band=6;
    for(const ring of rings)ring.forEach((a,i)=>{
      const b=ring[(i+1)%ring.length],s={a,b},bb=bounds([a,b]);
      index.put(bb,s);
      for(let k=Math.floor((bb.y0-tolerance)/band);k<=Math.floor((bb.y1+tolerance)/band);k++){
        if(!byHeight.has(k))byHeight.set(k,[]);byHeight.get(k).push(s);
      }
    });
    function has(p){
      let value=false;
      for(const {a,b} of byHeight.get(Math.floor(p[1]/band))||[]){
        if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])value=!value;
        if(p[0]>=Math.min(a[0],b[0])-tolerance&&p[0]<=Math.max(a[0],b[0])+tolerance&&dist(p,on(a,b,p).p)<tolerance)return true;
      }
      return value;
    }
    function fits(poly){
      if(!poly.every(has))return false;
      const bb=bounds(poly);
      for(const {a,b} of index.near(bb)){
        for(let i=0;i<poly.length;i++){
          const hit=cuts(poly[i],poly[(i+1)%poly.length],a,b);
          if(hit&&hit.t>1e-7&&hit.t<1-1e-7&&hit.s>1e-7&&hit.s<1-1e-7)return false;
        }
        if(a[0]>bb.x0+tolerance&&a[0]<bb.x1-tolerance&&a[1]>bb.y0+tolerance&&a[1]<bb.y1-tolerance&&inside(a,poly)&&poly.every((p,i)=>dist(a,on(p,poly[(i+1)%poly.length],a).p)>tolerance))return false;
      }
      return has(poly.reduce((s,p)=>add(s,p,1/poly.length),[0,0]));
    }
    return {has,fits};
  }
  // Horizontal scan of a region with holes; endpoints lie exactly on its edges.
  function spans(rings,y,vertical=false){
    const xs=[],i=vertical?1:0,j=1-i;
    for(const r of rings)for(let k=0;k<r.length;k++){
      const a=r[k],b=r[(k+1)%r.length];
      if((a[j]>y)!==(b[j]>y))xs.push(a[i]+(b[i]-a[i])*(y-a[j])/(b[j]-a[j]));
    }
    xs.sort((a,b)=>a-b);
    const out=[];for(let k=0;k+1<xs.length;k+=2)if(xs[k+1]-xs[k]>tolerance)out.push([xs[k],xs[k+1]]);
    return out;
  }
  function strip(a,b,w){const n=left(unit(sub(b,a)));return positive([add(a,n,w/2),add(b,n,w/2),add(b,n,-w/2),add(a,n,-w/2)]);}
  // Keep true bay footprints intact. A shared rear marking belongs to one bay.
  const markingCache=new WeakMap();
  function stallMarkings(stalls,frontages){
    if(markingCache.has(stalls))return markingCache.get(stalls);
    const backs=new Index(8),seam=.06,eps=.0001;
    const records=stalls.map((ring,i)=>{
      const front=frontages?.[i]?.p;
      if(ring.length!==4||!front)return null;
      // Packing emits the two aisle-parallel edges at 0 and 2, in either winding.
      const axis=unit(sub(ring[1],ring[0]));
      const setback=j=>Math.abs(cross(axis,sub(ring[j],front)));
      const j=setback(0)>setback(2)?0:2,a=ring[j],b=ring[j+1];
      const u=unit(sub(b,a)),towardBack=sub(a,ring[(j+3)%4]);
      const n=left(u).map(v=>v*Math.sign(cross(u,towardBack)));
      const box=bounds([a,b]),record={i,j,a,b,u,n,length:dist(a,b),box};
      backs.put(box,record);return record;
    });
    const markings=stalls.map((ring,i)=>{
      const rear=records[i],full=[{points:ring,closed:true}];
      if(!rear)return full;
      const {a,b,u,n,j,box}=rear,spans=[];
      const near=backs.near({x0:box.x0-seam,y0:box.y0-seam,x1:box.x1+seam,y1:box.y1+seam});
      for(const other of near){
        if(other.i>=i||dot(n,other.n)>-.999999)continue;
        const offsets=[sub(other.a,a),sub(other.b,a)];
        if(offsets.some(v=>dot(v,n)<-eps||dot(v,n)>seam))continue;
        const distances=offsets.map(v=>dot(v,u));
        const lo=Math.max(0,Math.min(...distances)),hi=Math.min(rear.length,Math.max(...distances));
        if(hi-lo>eps)spans.push([lo,hi]);
      }
      if(!spans.length)return full;
      const cuts=[];
      for(const interval of spans.sort((x,y)=>x[0]-y[0])){
        const last=cuts.at(-1);
        if(last&&interval[0]<=last[1]+eps)last[1]=Math.max(last[1],interval[1]);
        else cuts.push(interval);
      }
      const outline=[b,ring[(j+2)%4],ring[(j+3)%4],a];
      if(rear.length-cuts.at(-1)[1]>eps)outline.unshift(add(a,u,cuts.at(-1)[1]));
      if(cuts[0][0]>eps)outline.push(add(a,u,cuts[0][0]));
      const lines=[{points:outline,closed:false}];
      for(let k=1;k<cuts.length;k++)lines.push({points:[add(a,u,cuts[k-1][1]),add(a,u,cuts[k][0])],closed:false});
      return lines;
    });
    markingCache.set(stalls,markings);
    return markings;
  }
  // Cut only the connected gate mouths out of the perimeter of the united road.
  // Each remaining run is one polyline, including the run crossing ring index zero.
  function roadMarkings(surface,openings={}){
    const mouths=Object.values(openings).filter(g=>g?.connected&&g.points?.length===2).map(g=>g.points);
    const marks=[];
    for(const ring of surface){
      if(ring.length<3)continue;
      const runs=[];let cut=false;
      function retain(a,b){
        if(dist(a,b)<1e-6)return;
        const last=runs.at(-1);
        if(last&&dist(last.at(-1),a)<1e-6)last.push(b);
        else runs.push([a,b]);
      }
      for(let i=0;i<ring.length;i++){
        const a=ring[i],b=ring[(i+1)%ring.length],u=unit(sub(b,a)),len=dist(a,b),gaps=[];
        for(const [p,q] of mouths){
          const v=sub(p,a),w=sub(q,a);
          if(Math.max(Math.abs(cross(u,v)),Math.abs(cross(u,w)))>.002)continue;
          const s=dot(u,v),t=dot(u,w),lo=Math.max(0,Math.min(s,t)),hi=Math.min(len,Math.max(s,t));
          if(hi-lo>1e-5)gaps.push([lo,hi]);
        }
        if(!gaps.length){retain(a,b);continue;}
        cut=true;
        let cursor=0;
        for(const [lo,hi] of gaps.sort((x,y)=>x[0]-y[0])){
          if(lo>cursor)retain(add(a,u,cursor),add(a,u,lo));
          cursor=Math.max(cursor,hi);
        }
        if(cursor<len)retain(add(a,u,cursor),b);
      }
      if(!cut){marks.push({points:ring,closed:true});continue;}
      if(runs.length>1&&dist(runs.at(-1).at(-1),runs[0][0])<1e-6){
        const tail=runs.pop();runs[0]=tail.concat(runs[0].slice(1));
      }
      for(const points of runs)marks.push({points,closed:false});
    }
    return marks;
  }
  const outlineCache=new WeakMap();
  // A hatch hole touching its shell can display as solid pavement over a bed.
  // Cut at the contact heights. Adjacent solid fills need no visible divider.
  function pavingFaces(group,splitHoles=false){
    const epsilon=.000002, edges=new Index(9), levels=new Set();
    group.forEach((ring,k)=>ring.forEach((a,j)=>{
      const b=ring[(j+1)%ring.length];
      edges.put(bounds([a,b]),{a,b,j,k});
    }));
    group.forEach((ring,k)=>ring.forEach((p,i)=>{
      const [x,y]=p;
      for(const e of edges.near({x0:x-epsilon,x1:x+epsilon,y0:y-epsilon,y1:y+epsilon})){
        if(e.k===k&&(i===e.j||i===(e.j+1)%ring.length))continue;
        if(dist(p,on(e.a,e.b,p).p)<epsilon){levels.add(y);break;}
      }
    }));
    if(!levels.size&&(!splitHoles||group.length===1))return [group];
    const box=bounds(group[0]);
    levels.add(box.y0-1);levels.add(box.y1+1);
    for(const hole of group.slice(1)){
      const b=bounds(hole);levels.add((b.y0+b.y1)/2);
    }
    const ys=[...levels].sort((a,b)=>a-b), faces=[];
    for(let i=1;i<ys.length;i++){
      const low=ys[i-1],high=ys[i];
      if(high-low<1/scale)continue;
      const cut=[[box.x0-1,low],[box.x1+1,low],[box.x1+1,high],[box.x0-1,high]];
      faces.push(...groups(intersect(group,[cut])));
    }
    return faces;
  }
  function planOutlines(state){
    if(!outlineCache.has(state)){
      const origin=state.zone.boundary[0];
      const groupWorld=(rings,paved=false)=>{
        const sets=groups((rings||[]).map(r=>r.map(p=>sub(p,origin))));
        return (paved?sets.flatMap(g=>pavingFaces(g,true)):sets).map(group=>group.map(r=>r.map(p=>add(p,origin))));
      };
      const planting=state.greenBeds?.map(b=>b.rings)??groupWorld(state.green);
      outlineCache.set(state,{
        hardscape:groupWorld(state.hardscape,true),wall:groupWorld(state.wall),curb:groupWorld(state.curb),
        planting,green:planting.flat().map(points=>({points,closed:true})),
        road:roadMarkings(state.roadSurface,state.openings),
        stalls:state.stalls.map(points=>({points,closed:true}))
      });
    }
    return outlineCache.get(state);
  }
  function disk(p,r,n=16){return Array.from({length:n},(_,i)=>add(p,[Math.cos(2*Math.PI*i/n),Math.sin(2*Math.PI*i/n)],r));}
  function pieces(rings){
    const out=[];
    for(const [outer,...holes] of groups(rings)){
      if(!holes.length){out.push(outer);continue;}
      const b=bounds(outer),ys=[b.y0-1,...holes.map(h=>{const b=bounds(h);return (b.y0+b.y1)/2;}),b.y1+1].sort((a,b)=>a-b);
      for(let i=1;i<ys.length;i++)if(ys[i]-ys[i-1]>tolerance){
        const rect=[[b.x0-1,ys[i-1]],[b.x1+1,ys[i-1]],[b.x1+1,ys[i]],[b.x0-1,ys[i]]];
        for(const r of intersect([outer,...holes],[rect]))if(signed(r)>1e-6)out.push(r);
      }
    }
    return out;
  }
  return {laneProbe,roundGrass,joinGrassKerbs,grassRadius,curveArea,sampleGrassRing,plantingFaces,pavingFaces,add,sub,dot,cross,dist,unit,left,lerp,on,signed,positive,area,siteArea,bounds,union,intersect,minus,groups,offset,inside,cuts,Index,overlap,prepare,spans,strip,stallMarkings,roadMarkings,planOutlines,disk,pieces};
}
globalThis.createParkingGeometry=createParkingGeometry;
