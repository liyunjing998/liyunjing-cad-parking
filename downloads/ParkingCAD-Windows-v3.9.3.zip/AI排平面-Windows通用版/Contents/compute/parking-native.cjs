// Runs in the bundled Windows runtime. The CAD host owns selection and writeback.
'use strict';
const fs = require('node:fs');
require('./engine.js');
require('./cad-plan.js');
require('./cad-bridge.js');

function preview(plan) {
  const colors = {STALL: 2, GREEN: 3, ROUTE: 4, PORT: 1};
  const lines = [];
  for (const item of plan.items) {
    const color=colors[item.layer]||({[0xe83c31]:1,[0xf2a32b]:2,[0x74b8d4]:4})[item.pen];
    if (item.kind !== 'P' || !color) continue;
    const vertices = item.vertices;
    for (let i = 0; i < vertices.length - (item.closed ? 0 : 1); i++) {
      const a = vertices[i], b = vertices[(i + 1) % vertices.length];
      const emit=(p,q)=>lines.push('(' + [color,p[0],p[1],q[0],q[1]]
        .map(n=>n.toFixed(6)).join(' ') + ')');
      if(!a[2]){emit(a,b);continue;}
      const bulge=a[2],sweep=4*Math.atan(bulge),k=(1-bulge*bulge)/(4*bulge);
      const x=(a[0]+b[0])/2-(b[1]-a[1])*k,y=(a[1]+b[1])/2+(b[0]-a[0])*k;
      const start=Math.atan2(a[1]-y,a[0]-x),radius=Math.hypot(a[0]-x,a[1]-y);
      const count=Math.ceil(Math.abs(sweep)/(Math.PI/36));
      let p=a;
      for(let j=1;j<=count;j++){
        const angle=start+sweep*j/count;
        const q=j===count?b:[x+radius*Math.cos(angle),y+radius*Math.sin(angle)];
        emit(p,q);p=q;
      }
    }
  }
  return lines.join('\n');
}

function generate(input, branchWidth, endTreatment) {
  const zone = JSON.parse(fs.readFileSync(input, 'utf8').replace(/^\uFEFF/, ''));
  const results = ParkingEngine.alternatives(zone, {branchWidth, endTreatment, direction:'hierarchy'});
  const rows = [];
  for (const layout of results) {
    if (!layout.exportable) continue;
    const slot = layout.scheme, path = input + '.' + slot;
    const plan = ParkingCadPlan.plan(layout, {scheme:slot});
    fs.writeFileSync(path + '.pzt', ParkingBridge.clean(layout, plan.items));
    fs.writeFileSync(path + '.preview', preview(plan));
    const overlay=ParkingCadPlan.bandItems(plan.notes);
    fs.writeFileSync(path+'.band.preview',preview({items:[...plan.items,...overlay]}));
    const cut=layout.grassCleanup,check=plan.notes.clearance;
    rows.push([slot,layout.stats.spaces,layout.kerbArcs.filter(a=>a.inner).length,layout.unroundedKerbs,
      cut.clipped,cut.corners-cut.clipped,cut.reduced,cut.skipped,check.overlap,check.touch,check.unresolved,cut.byStalls].join(' '));
  }
  // Publish the list only after every available drawing is complete.
  fs.writeFileSync(input + '.list', rows.join('\n'));
}
try {
  const [input,width,treatment] = process.argv.slice(2);
  generate(input, Number(width), treatment);
} catch (error) {
  if (process.argv[2]) fs.writeFileSync(process.argv[2]+'.error',
    ['AREA_LIMIT','STALL_LIMIT','UNITS'].includes(error.code) ? error.code : 'GEOMETRY');
  process.exitCode = 1;
}
