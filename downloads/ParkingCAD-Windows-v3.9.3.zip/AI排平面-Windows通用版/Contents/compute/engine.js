/* Public entry point shared by the offline page, its worker and the file CLI. */
if (typeof module !== 'undefined' && module.exports) {
  require('./vendor/clipper.js');
  require('./tree-symbols.js');
  require('./geometry.js');
  require('./roads.js');
  require('./routing.js');
  require('./planner.js');
}
function createParkingEngine(G,planner) {
  'use strict';
  const VERSION = 'parking-rules/2026-11-25-shared-kerb';
  const RULES = Object.freeze({
    parallel: { label: '平行式 · 后退', depth: 2.4, pitch: 6.0, operation: 3.8, angle: 0, source: 'JGJ 100-2015 表4.3.4' },
    angle30: { label: '斜列 30° · 前进/后退', depth: 4.8, pitch: 4.8, operation: 3.8, angle: 30, source: 'JGJ 100-2015 表4.3.4' },
    angle45: { label: '斜列 45° · 前进/后退', depth: 5.5, pitch: 3.4, operation: 3.8, angle: 45, source: 'JGJ 100-2015 表4.3.4' },
    angle60forward: { label: '斜列 60° · 前进', depth: 5.8, pitch: 2.8, operation: 4.5, angle: 60, source: 'JGJ 100-2015 表4.3.4' },
    angle60reverse: { approach:'reverse', label: '斜列 60° · 后退', depth: 5.8, pitch: 2.8, operation: 4.2, angle: 60, source: 'JGJ 100-2015 表4.3.4' },
    perpendicularForward: { label: '垂直式 · 前进', depth: 5.3, pitch: 2.4, operation: 9.0, angle: 90, source: 'JGJ 100-2015 表4.3.4' },
    perpendicularReverse: { label: '垂直式 · 后退', depth: 5.3, pitch: 2.4, operation: 5.5, angle: 90, source: 'JGJ 100-2015 表4.3.4' }
  });
  const baySizes={
    '5.4x2.4':{depth:5.4,pitch:2.4,color:'#d6b881'},
    '5.4x2.5':{depth:5.4,pitch:2.5,color:'#a99ac5'},
    '5.7x2.5':{depth:5.7,pitch:2.5,color:'#92b8d8'},
    '5.3x2.4':{depth:5.3,pitch:2.4,color:'#c7bc9a'}
  };
  const parallelSizes={
    '6.0x2.7':{depth:2.7,pitch:6.0,color:'#80b7ac'},
    '6.0x2.4':{depth:2.4,pitch:6.0,color:'#99bbb3'},
    '6.2x2.5':{depth:2.5,pitch:6.2,color:'#87b5a0'}
  };
  function ruleFor(mode,size,parallelSize,floor=null){
    if(mode==='parallel')return {...RULES[mode],...parallelSizes[parallelSize],source:'项目所选平行车位规格'};
    const r=RULES[mode];
    if(r.angle===90)return {...r,...baySizes[size],source:'项目所选垂直车位规格'};
    if(!floor)return r;
    // Reserve a full length-by-width rectangle parallel to the slanted bay sides.
    const theta=r.angle*Math.PI/180,sin=Math.sin(theta),cmUp=n=>Math.ceil(n*100-1e-8)/100;
    return {...r,depth:Math.max(r.depth,cmUp(floor.length*sin+floor.width*Math.cos(theta))),
      pitch:Math.max(r.pitch,cmUp(floor.width/sin))};
  }
  function stallRule(layout,i){
    return ruleFor(layout.stallModes[i],layout.stallSizes?.[i]||layout.baySize||'5.3x2.4',
      layout.parallelSize||'6.0x2.4',layout.sizeFloor);

  }
  const grouped=new WeakMap();
  function stallGroups(layout){
    if(grouped.has(layout))return grouped.get(layout);
    const groups=new Map();
    layout.stalls.forEach((ring,i)=>{
      const r=stallRule(layout,i);
      const key=[r.angle,r.depth,r.pitch].join('/');
      if(!groups.has(key)){
        const color=r.color||({0:'#83beb7',30:'#d4a090',45:'#cf92b1',60:'#8ba3ce'})[r.angle];
        const label=r.angle===90?'垂直 '+r.depth+' × '+r.pitch:r.angle===0?'平行 '+r.pitch.toFixed(1)+' × '+r.depth:
          r.angle+'°斜列 排深'+r.depth+' 节距'+r.pitch;
        groups.set(key,{label,color,rings:[],insets:[]});
      }
      const group=groups.get(key),origin=ring[0];
      const local=G.positive(ring.map(p=>G.sub(p,origin)));
      const holes=G.offset([local],-.30).map(r=>G.positive(r).reverse().map(p=>G.add(p,origin)));
      group.rings.push(ring);
      group.insets.push(...holes);
    });
    const result=[...groups.values()];
    grouped.set(layout,result);return result;
  }
  const EPS = 1e-7;
  const area = G.signed;
  const cross = (a, b, c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
  const onSegment = (p, a, b) => Math.abs(cross(a,b,p)) < EPS && p[0] >= Math.min(a[0],b[0])-EPS && p[0] <= Math.max(a[0],b[0])+EPS && p[1] >= Math.min(a[1],b[1])-EPS && p[1] <= Math.max(a[1],b[1])+EPS;
  function segmentsCross(a,b,c,d) {
    const x=cross(a,b,c), y=cross(a,b,d), z=cross(c,d,a), w=cross(c,d,b);
    if (Math.abs(x)<EPS && onSegment(c,a,b) || Math.abs(y)<EPS && onSegment(d,a,b) || Math.abs(z)<EPS && onSegment(a,c,d) || Math.abs(w)<EPS && onSegment(b,c,d)) return true;
    return (x>0)!==(y>0) && (z>0)!==(w>0);
  }
  function pointInPolygon(p, poly) {
    let inside=false;
    for(let i=0,j=poly.length-1;i<poly.length;j=i++) {
      const a=poly[j], b=poly[i];
      if(onSegment(p,a,b)) return true;
      if((a[1]>p[1]) !== (b[1]>p[1]) && p[0] < (b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0]) inside=!inside;
    }
    return inside;
  }
  function validPolygon(poly) {
    if(!Array.isArray(poly) || poly.length<3 || poly.length>2048 || poly.some(p=>!Array.isArray(p)||p.length!==2||p.some(v=>!Number.isFinite(v)))) return false;
    if(poly.some((p,i)=>Math.hypot(p[0]-poly[(i+1)%poly.length][0],p[1]-poly[(i+1)%poly.length][1])<EPS)) return false;
    if(Math.abs(area(poly))<EPS) return false;
    for(let i=0;i<poly.length;i++) for(let j=i+1;j<poly.length;j++) {
      if(j===i+1 || i===0 && j===poly.length-1) continue;
      if(segmentsCross(poly[i],poly[(i+1)%poly.length],poly[j],poly[(j+1)%poly.length])) return false;
    }
    return true;
  }
  function normalize(input) {
    if(!input || input.schema!=='parking-zone/v1' || input.unit!=='m' || !validPolygon(input.boundary)) throw Error('请输入合法的 parking-zone/v1 米制闭合简单多边形；首点无需重复。');
    const obstacles=input.obstacles || [];
    if(!Array.isArray(obstacles) || obstacles.some(p=>!validPolygon(p))) throw Error('障碍物须为闭合简单多边形数组。');
    for(const name of ['entrance','exit']) {
      const p=input[name];
      if(p!==null && p!==undefined && (!Array.isArray(p)||p.length!==2||p.some(v=>!Number.isFinite(v)))) throw Error(`${name} 应为 [x,y] 或 null。`);
    }
    let mapReference;
    if (input.mapReference != null) {
      const r=input.mapReference, pair=p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite);
      if (r.crs!=='GCJ-02'||!pair(r.origin)||Math.abs(r.origin[0])>180||Math.abs(r.origin[1])>=85||!pair(r.anchor)||!Number.isFinite(r.rotation)) throw Error('场地的地图定位参数无效。');
      mapReference={crs:r.crs,origin:r.origin.slice(),anchor:r.anchor.slice(),rotation:r.rotation};
    }
    const ground=obstacles.map((_,i)=>['green','paved'].includes(input.obstacleGround?.[i])?input.obstacleGround[i]:'pending');
    return {...(mapReference?{mapReference}:{}),...(ground.some(material=>material!=='pending')?{obstacleGround:ground}:{}),schema:'parking-zone/v1',unit:'m',id:String(input.id || 'P1'),boundary:input.boundary.map(p=>p.slice()),entrance:input.entrance ?? null,exit:input.exit ?? null,obstacles:obstacles.map(poly=>poly.map(p=>p.slice()))};
  }
  function box(poly) { return {minX:Math.min(...poly.map(p=>p[0])),maxX:Math.max(...poly.map(p=>p[0])),minY:Math.min(...poly.map(p=>p[1])),maxY:Math.max(...poly.map(p=>p[1]))}; }
  function nearBoundary(p,poly) {if(!p)return false;return poly.some((a,i)=>{const b=poly[(i+1)%poly.length],dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)<.003;});}
  function checkParcelSize(boundary) {
    const grossArea=G.siteArea(boundary),bounds=box(boundary);
    if(!Number.isFinite(grossArea) || grossArea>50000){
      const measured=Number.isFinite(grossArea)?Math.ceil(grossArea).toLocaleString('zh-CN')+' m²':'无效';
      throw Object.assign(Error('地块面积 '+measured+'，单块上限 50,000 m²。请核对原图单位是否为毫米；大型用地请分区生成。'),{code:'AREA_LIMIT'});
    }
    if(Math.max(bounds.maxX-bounds.minX,bounds.maxY-bounds.minY)>100000)
      throw Object.assign(Error('地块尺寸超出单次排布范围。请核对原图单位是否为毫米；大型用地可分区生成。'),{code:'UNITS'});
  }
  function alternatives(raw,opts={}) {
    const zone=normalize(raw),requestedMode=opts.mode||'perpendicularReverse';
    checkParcelSize(zone.boundary);
    const direction=opts.direction|| (opts.aisleStandard==='minimum'?'twoway':'hierarchy');
    if(!['hierarchy','oneway','twoway'].includes(direction))throw Error('未知车道交通组织方式。');
    const hierarchy=direction==='hierarchy',branchWidth=Number(opts.branchWidth??6),endTreatment=opts.endTreatment??'edgeLawn';
    if(![6,7].includes(branchWidth)||!['edgeLawn','island'].includes(endTreatment))throw Error('支路净宽或端部排布选项无效。');
    const orientation=['x','y'].includes(opts.orientation)?opts.orientation:'auto';
    const eco=opts.siteStyle==='eco',infill=opts.mixedEdges!==false;
    const modes=requestedMode==='auto'
      ?(opts.manualRoads?.length?[opts.manualMode||'perpendicularReverse']:['perpendicularReverse','angle60reverse','angle45','parallel'])
      :[requestedMode];
    const baySize=opts.baySize||'5.4x2.4';
    const parallelSize=opts.parallelSize||'6.0x2.7';
    if(!Object.hasOwn(parallelSizes,parallelSize)||!Object.hasOwn(baySizes,baySize))throw Error('未知车位规格。');
    const minBaySize=opts.minBaySize||'primary',aisleStandard=opts.aisleStandard||'preferred';
    if(!['primary','byMode'].includes(minBaySize)&&!Object.hasOwn(baySizes,minBaySize))throw Error('未知最小车位规格。');
    if(!['preferred','minimum'].includes(aisleStandard))throw Error('未知车道宽度设置。');
    const primary=baySizes[baySize],parallel=parallelSizes[parallelSize];
    const floorSize=minBaySize==='primary'?primary:baySizes[minBaySize];
    const sizeFloor=minBaySize==='primary'&&requestedMode==='parallel'?{length:parallel.pitch,width:parallel.depth}:
      floorSize?{length:floorSize.depth,width:floorSize.pitch}:null;
    function fitsMinimum(r){
      if(!sizeFloor||r.angle%90!==0)return true;
      const length=r.angle===0?r.pitch:r.depth,width=r.angle===0?r.depth:r.pitch;
      return length>=sizeFloor.length&&width>=sizeFloor.width;
    }
    const curbWidth=Number(opts.curbWidth||0),wallWidth=Number(opts.wallWidth||0),wallSide=opts.wallSide||'center';
    if(![0,.10,.15,.20].includes(curbWidth)||![0,.18,.3,.5].includes(wallWidth)||
       !['inside','outside','center'].includes(wallSide))throw Error('路缘石或围墙参数无效。');
    let total=0;
    const pool=[];
    for(const mode of modes){
      if(!Object.hasOwn(RULES,mode))throw Error('未知停车方式。');
      const rule=ruleFor(mode,baySize,parallelSize,sizeFloor);
      if(!fitsMinimum(rule)){
        if(modes.length>1)continue;
        throw Error('主要车位规格小于所选下限，请调大主要规格或调整最小尺寸。');
      }
      const targetWidth=hierarchy?7:direction==='oneway'?5.5:(aisleStandard==='preferred'?7:6);
      const aisleWidth=hierarchy?7:Math.max(targetWidth,rule.operation);
      const serviceWidth=hierarchy?Math.max(branchWidth,rule.operation):aisleWidth;
      const packing=[mode];
      if(infill)for(const key of ['parallel','angle60reverse','angle45','perpendicularReverse']){
        if(!packing.includes(key)&&RULES[key].operation<=aisleWidth)packing.push(key);
      }
      const parkingModes=packing.map(key=>({mode:key,size:baySize,rule:ruleFor(key,baySize,parallelSize,sizeFloor)})).filter(p=>fitsMinimum(p.rule));
      if(infill&&Object.hasOwn(baySizes,minBaySize)&&minBaySize!==baySize&&
          primary.depth>=sizeFloor.length&&primary.pitch>=sizeFloor.width){
        const secondaryMode=rule.angle===90?mode:'perpendicularReverse';
        const fallback=ruleFor(secondaryMode,minBaySize,parallelSize);
        if(fallback.operation<=aisleWidth)parkingModes.push({mode:secondaryMode,size:minBaySize,rule:fallback});
      }
      const config={rule,curbWidth,wallWidth,wallSide,w:aisleWidth,hierarchy,serviceWidth,branchWidth,endTreatment,oneway:direction==='oneway',eco,parkingModes};
      const onCompared=opts.onProgress?(count=>opts.onProgress(rule.label,total+count)):null;
      if(onCompared)onCompared(0);
      const results=planner.alternatives(zone,{...opts,direction,orientation,onCompared},config);
      total+=results[0]?.stats.candidates??0;
      for(const r of results){
        if(!r.stats.spaces)continue;
        pool.push({...r,variantId:mode+'|'+r.variantId,version:VERSION,zone,mode,requestedMode,baySize,parallelSize,minBaySize,sizeFloor,aisleStandard,targetWidth,curbWidth,wallWidth,wallSide,
          direction,orientation,rule,aisleWidth,branchWidth,endTreatment,siteStyle:eco?'eco':'standard',mixedEdges:infill});
      }
    }
    if(!pool.length)throw planner.stallLimitError();
    if(modes.length===1)return pool;
    const gates=s=>Number(s.graph.connected.entrance)+Number(s.graph.connected.exit);
    const rank=(a,b)=>gates(b)-gates(a)||Number(b.graph.connected.entrance)-Number(a.graph.connected.entrance)||
      b.stats.reachable-a.stats.reachable||b.stats.spaces-a.stats.spaces||a.stats.deadEnds-b.stats.deadEnds||
      (a.stats.meanTrip??Infinity)-(b.stats.meanTrip??Infinity)||a.stats.roadArea-b.stats.roadArea;
    if(opts.manualRoads?.length)return pool.sort(rank).slice(0,1);
    const selected=[];
    for(const slot of ['A','B','C']){
      const base=selected.find(s=>s.scheme==='B');
      const candidates=pool.filter(s=>s.scheme===slot&&(slot!=='C'||s.mode===base?.mode));
      const best=candidates.sort(rank)[0];
      if(best){best.stats.candidates=total;selected.push(best);}
    }
    return selected;
  }
  function layout(raw,opts){return alternatives(raw,opts)[0];}
  function areaSchedule(areas){
    const keys=['paved','green','stalls'];if(areas.wall!==undefined)keys.push('wall');
    if(areas.pending!==undefined)keys.push('pending');
    const hundredths=areas.total*100;
    const total=Math.round(hundredths+Number.EPSILON*Math.max(1,hundredths));
    const cents={total},fractions=[];
    for(const key of keys){
      const value=Math.max(0,areas[key]*100);
      cents[key]=Math.floor(value);
      fractions.push({key,remainder:value-cents[key]});
    }
    // Round once so all printed surface areas add up to the printed site area.
    const extra=total-keys.reduce((sum,key)=>sum+cents[key],0);
    if(extra<0||extra>keys.length)throw Error('面积分项与用地轮廓不符，请复核面域。');
    fractions.sort((a,b)=>b.remainder-a.remainder);
    for(let i=0;i<extra;i++)cents[fractions[i].key]++;
    return Object.fromEntries(Object.entries(cents).map(([key,value])=>[key,value/100]));
  }
  function cleanGrass(s){
    // Previously filleted results are final geometry. Fresh generation starts
    // from the site and restores shared corners, including for older projects.
    if(['graded-v1','graded-v2','graded-v3','graded-v4'].includes(s.grassCleanup?.rule))return s;
    const origin=s.zone.boundary[0];
    const local=rs=>rs.map(r=>r.map(p=>G.sub(p,origin)));
    const world=rs=>rs.map(r=>r.map(p=>G.add(p,origin)));
    const kerbs=(s.kerbArcs||[]).map(a=>({...a,points:local([a.points])[0]}));
    const road=s.roadSurface?local(s.roadSurface):G.union(local(s.aisles||[]));
    const roadEdges=s.curbWidth?G.offset(road,s.curbWidth):road;
    const fixedEdges=local([s.zone.boundary,...(s.zone.obstacles||[])]);
    const original=local(s.green),cut=G.roundGrass(G.groups(original),kerbs,s.curbWidth,{stalls:local(s.stalls||[]),roadEdges,fixedEdges});
    const planting=cut.beds.flat(),grassCleanup=cut.summary;
    const site=G.minus([G.positive(fixedEdges[0])],G.union([...fixedEdges.slice(1).map(G.positive),...local(s.wall||[])]));
    const finish=G.joinGrassKerbs(road,local(s.curb||[]),local(s.hardscape||s.paving||[]),original,planting,cut,s.curbWidth||0,site);
    const paving=G.minus(local(s.paving||[]),finish.moved),pavedGround=G.union([...finish.road,...finish.hardscape,...finish.curb]);
    const pending=G.minus(G.union([...local(s.pending||[]),...G.minus(original,planting)]),finish.moved);
    const greenBeds=cut.beds.map((r,i)=>({id:i+1,rings:world(r),area:cut.areas[i],
      curves:cut.outlines[i].map(loop=>loop.map(([x,y,b])=>[...G.add([x,y],origin),b]))}));
    const crownRoom=G.prepare(planting);
    const trees=s.trees.filter(p=>{
      const q=G.sub(p,origin),r=ParkingTrees.radius*ParkingTrees.placement(p).scale;
      return crownRoom.fits(G.disk(q,r/Math.cos(Math.PI/32),32));
    });
    const trim=rs=>world(G.intersect(local(rs),planting));
    const landscape=s.landscape?{...s.landscape,rings:trim(s.landscape.rings)}:null;
    if(landscape)landscape.area=G.area(landscape.rings);
    const patches=G.groups(paving).map(r=>({kind:'pave',rings:world(r),area:G.area(r)}));
    for(const p of s.patches||[])if(p.kind==='bed'||p.kind==='tree'){
      for(const r of G.groups(G.intersect(local(p.rings),planting)))patches.push({kind:p.kind,rings:world(r),area:G.area(r)});
    }
    for(const r of G.groups(pending))patches.push({kind:'pending',rings:world(r),area:G.area(r)});
    const greenArea=cut.areas.reduce((n,a)=>n+a,0),arcDifference=greenArea-G.area(planting),pendingArea=G.area(pending);
    const pavedArea=G.area(pavedGround)-arcDifference,roadArea=G.area(finish.road)-(s.curbWidth?0:arcDifference);
    const stats={...s.stats,greenArea,pendingArea,pavedArea,roadArea,marginArea:G.area(paving),
      curbArea:G.area(finish.curb)-(s.curbWidth?arcDifference:0),treeCount:trees.length,
      surfaceAreas:{...s.stats.surfaceAreas,paved:pavedArea,green:greenArea,pending:pendingArea}};
    return {...s,grassCleanup,greenBeds,green:greenBeds.flatMap(b=>b.rings),pending:world(pending),trees,patches,
      roadSurface:world(finish.road),aisles:world(G.pieces(finish.road)),curb:world(finish.curb),
      hardscape:world(finish.hardscape),pavedGround:world(pavedGround),paving:world(paving),treeIslands:trim(s.treeIslands||[]),landscape,stats};
  }
  function resultObject(s){
    return {schema:'parking-result/v1',unit:'m',id:s.zone.id,boundary:s.zone.boundary,sourceZone:s.zone,
      ruleVersion:VERSION,method:s.method,strategy:s.strategy,scheme:s.scheme,schemeName:s.schemeName,variantId:s.variantId,parameters:{kerbRadius:s.kerbRadius,branchWidth:s.branchWidth,endTreatment:s.endTreatment,minBaySize:s.minBaySize,aisleStandard:s.aisleStandard,parallelSize:s.parallelSize,baySize:s.baySize,curbWidth:s.curbWidth,wallWidth:s.wallWidth,wallSide:s.wallSide,mode:s.mode,requestedMode:s.requestedMode,direction:s.direction,orientation:s.orientation,aisleWidth:s.aisleWidth,siteStyle:s.siteStyle,mixedEdges:s.mixedEdges},
      checks:s.checks,stats:s.stats,areaSchedule:areaSchedule(s.stats.surfaceAreas),stalls:s.stalls,aisles:s.aisles,roadSurface:s.roadSurface,kerbArcs:s.kerbArcs,unroundedKerbs:s.unroundedKerbs,kerbLimits:s.kerbLimits,grassCleanup:s.grassCleanup,green:s.green,paving:s.paving,pavedGround:s.pavedGround,hardscape:s.hardscape,curb:s.curb,wall:s.wall,pending:s.pending,
      stallModes:s.stallModes,stallSizes:s.stallSizes,sizeFloor:s.sizeFloor,patches:s.patches,treeIslands:s.treeIslands,trees:s.trees,graph:s.graph,openings:s.openings,runs:s.runs,rows:s.rows,frontages:s.frontages,greenBeds:s.greenBeds,landscape:s.landscape};
  }
  return {checkParcelSize,cleanGrass,VERSION,RULES,baySizes,parallelSizes,ruleFor,stallRule,stallGroups,normalize,validPolygon,pointInPolygon,nearBoundary,box,layout,alternatives,resultObject,areaSchedule,siteArea:G.siteArea,stallMarkings:G.stallMarkings,planOutlines:G.planOutlines};
}
globalThis.createParkingEngine=createParkingEngine;
{
  const geometry=createParkingGeometry(globalThis.ClipperLib);
  globalThis.ParkingEngine=createParkingEngine(geometry,createParkingPlanner(geometry,createParkingRoads(geometry)));
}
