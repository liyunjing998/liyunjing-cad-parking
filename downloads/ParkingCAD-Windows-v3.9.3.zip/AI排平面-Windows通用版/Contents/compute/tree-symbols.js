/* Tree block geometry in metres. Both crowns have a nominal diameter of 2.6 m.
   Short strokes are explicit so the drawing reads the same at any linetype scale. */
function createParkingTrees() {
  'use strict';
  const tau=2*Math.PI, radius=1.3;
  const names=['LYJ-PARK-TREE-OPEN-01','LYJ-PARK-TREE-FEATHER-01'];
  function crown(dense){
    const strokes=[], stems=dense?12:9;
    const polar=(r,a)=>[radius*r*Math.cos(a),radius*r*Math.sin(a)];
    function trace(curve,count,duty){
      for(let k=0;k<count;k++){
        const a=k/count,b=(k+duty)/count;
        strokes.push([curve(a),curve(b)].map(p=>p.map(v=>+v.toFixed(5))));
      }
    }
    for(let i=0;i<stems;i++){
      const a=tau*(i+.17*Math.sin(i*4.21))/stems;
      const length=(dense?.94:.86)+(dense?.04:.10)*Math.sin(2.65*i+.4);
      const sweep=(dense?.31:.21)+.12*Math.sin(i*1.7);
      const direction=t=>a+sweep*t+.09*Math.sin(Math.PI*t*(dense?1.4:1)+i*.65)*t;
      const stem=t=>polar(.025+(length-.025)*t,direction(t));
      trace(stem,dense?8:7,.67);
      const forks=dense?[[.38,-1],[.55,1],[.72,-1]]:[[.38,-1],[.56,1]];
      for(const [start,side] of forks){
        const r0=.025+(length-.025)*start, end=Math.min(1,length+.05*Math.cos(i+start));
        const branch=t=>polar(r0+(end-r0)*t,direction(start)+side*(dense?.21:.29)*Math.sin(t*1.45)+sweep*.55*t);
        trace(branch,dense?5:4,.61);
        if(dense){
          const u=.67,anchor=branch(u),r=Math.hypot(...anchor)/radius,theta=Math.atan2(anchor[1],anchor[0]);
          trace(t=>polar(r+(.99-r)*t,theta+side*.12*t),2,.58);
        }
      }
    }
    return strokes;
  }
  const styles=[crown(false),crown(true)];
  function placement(p){
    // Hash the actual planting position: repaint, export and regenerating a scheme
    // all reproduce the same choice for a tree that stays in place.
    let seed=2166136261;
    for(const c of p.map(v=>Math.round(v*1000)).join(','))seed=Math.imul(seed^c.charCodeAt(0),16777619);
    function next(){
      seed=(seed+0x6D2B79F5)|0;
      let v=Math.imul(seed^(seed>>>15),1|seed);
      v^=v+Math.imul(v^(v>>>7),61|v);
      return ((v^(v>>>14))>>>0)/4294967296;
    }
    return {style:Math.floor(next()*2),scale:+(.7+.5*next()).toFixed(4),angle:+(tau*next()).toFixed(6),p};
  }
  return {names,styles,placement,radius};
}
globalThis.createParkingTrees=createParkingTrees;
globalThis.ParkingTrees=createParkingTrees();
