;; BEGIN ParkingCAD - Li Yunjing AI
(if (and (getenv "APPDATA")
         (findfile (strcat (getenv "APPDATA") "/Gstarsoft/ParkingCAD/ParkingCAD.bundle/Contents/parking-bridge.lsp")))
  (load (strcat (getenv "APPDATA") "/Gstarsoft/ParkingCAD/ParkingCAD.bundle/Contents/parking-bridge.lsp")))
;; END ParkingCAD - Li Yunjing AI
